#include <iostream>
#include <iomanip>
#include <math.h>
#include <string>
#include <fstream>
#include <string.h>
#include <algorithm>
#include <cmath>

#include "fooditem.cpp" //including the file

using namespace std;
#define ITEMS 10

fooditem menu[ITEMS];
fooditem order[ITEMS];

int numItemsOrdered = 0;
double totalPrice = 0;

void addtoOrder()
{
    string choice;
    int menuItem;

    do
    {
        cout << "which menu item?";
        cin >> choice;

        if (choice >= "0" && choice <= "9")
        {
            menuItem = stoi(choice); // string to int
        }
    } while (menuItem < 0 || menuItem >= ITEMS);

    cout << "ordered " << menu[menuItem].getName() << endl;
    order[numItemsOrdered] = menu[menuItem];
    totalPrice += menu[menuItem].getCost();
    numItemsOrdered++;
}

void showOrder()
{
    for (int x=0; x < numItemsOrdered; x++)
    {
        cout << order[x].getName() << " " << order[x].getCost() << endl;
    }
    cout << "total cost " << totalPrice << endl;
}

void fillMenu()
{
    menu[0] = fooditem("pizza", 500, 5.5);
    menu[1] = fooditem("cheesyburber", 500, 5.5);
    menu[2] = fooditem("apple", 500, 5.5);
    menu[3] = fooditem("chicken tendies", 500, 5.5);
    menu[4] = fooditem("pop", 500, 5.5);
    menu[5] = fooditem("frenchie frisie", 500, 5.5);
    menu[6] = fooditem("candy", 500, 5.5);
    menu[7] = fooditem("cake", 500, 5.5);
    menu[8] = fooditem("eggs", 500, 5.5);
    menu[9] = fooditem("food", 500, 5.5);
}

void showMenu()
{

    cout << setw(4) << left << "num" << setw(20) << "food name" << setw(4) << right << "cost" << endl;
    cout << "-----------------------------------------------------\n";
    for (int x = 0; x < ITEMS; x++)
    {
        // cout<<menu[x].to_string()<<endl;
        cout << setw(4) << left << x << setw(20) << menu[x].getName() << setw(5) << right << menu[x].getCost() << endl;
    }
    cout << "-----------------------------------------------------\n";
}

int main()
{

    fillMenu();
    showMenu();

    char choice;
    // 1 to add to order, 2 show menu, 3 show order, 9 quit

    do
    {
        cout << "1 - enter an item in the order\n";
        cout << "2 - show the menu \n";
        cout << "3 - show current order\n";
        cout << "9 - quit out\n";
        cin >> choice;

        switch (choice)
        {

        case ('2'):
            showMenu();
            break;
        case ('1'):
            if (numItemsOrdered < ITEMS)
            {
                addtoOrder();
            }
            else
            {
                cout << "out of space in order\n";
            }
            // add to order
     //       addtoOrder();
        case ('3'):
            showOrder();
            break;
        case ('9'):
            cout << "good by here is your order";
            break;
        default:
            cout << choice << "is not a valid choice \n";
            break;
        }
        // cout << "Your chice " << choice << endl;
    } while (choice != '9');
    // cout << "ended\n";

    return 0;
}