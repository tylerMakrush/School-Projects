#ifndef CARDEAC_H
#define CARDEAC_H
#include <string>
using namespace std;
#define DOCINFO_H

#pragma once

class cardeac
{
public:
    cardeac();
    cardeac(double Blood, double dicnum);
    ~cardeac();

    void setBloodpres(double Bloodpres);
    double getBloodpres();

    void SetDicnum(double Dicnum);
    double getDicnum();

private:
double bloodpres;
double dicnum;

};

#endif