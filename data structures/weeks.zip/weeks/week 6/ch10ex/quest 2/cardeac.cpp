#include "cardeac.h"
#include <string>
using namespace std;
#define DOCINFO_H

cardeac::cardeac()
{

}

cardeac::~cardeac()
{

}