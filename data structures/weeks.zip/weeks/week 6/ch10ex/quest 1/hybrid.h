#ifndef HYBRID_H
#define HYBRID_H
#include "hybrid.h"
#include <string>

#pragma once
using namespace std;

class hybrid
{
public:
    hybrid();
    hybrid(string Battype, double Batsize, double Batharge);
    ~hybrid();

    string setBattype(string Battype);
    void getBattype();

    double setBatsize(double Batsize);
    void getBatsize();

    double setBatcharge(double Batcharge);
    void getBatcharge();

private:

string battype;
double batsize;
double batcharge;



};

#endif