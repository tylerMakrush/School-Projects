#include "hybrid.h"
#include "hybrid.h"
#include "hybrid.h"

hybrid::hybrid()
{

}
hybrid::hybrid(string Battype, double Batsize, double Batcharge){
    battype = Battype;
    batsize = Batsize;
    batcharge = Batcharge;
}
hybrid::~hybrid()
{

}