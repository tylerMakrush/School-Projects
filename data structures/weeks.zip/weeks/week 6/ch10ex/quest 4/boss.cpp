#include "boss.h"
#include "monstermaker.h"

boss::boss()
{

}
boss::boss(double Shield, double Super){
    shield = Shield;
    super = Super;
}

boss::~boss()
{

}
void boss::setShield(double Shield){
    shield = Shield;
}
double boss::getShield(){
    return shield;
}
void::setSuper(double Super){
    super = Super;
}
double boss::GetSuper(){
    return super;
}