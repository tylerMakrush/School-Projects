#ifndef BOSS_H
#define BOSS_H
#include "monstermaker.h"

#pragma once
using namespace std;

class boss
{
public:
    boss();
    boss(double Shield, double Super);
    ~boss();
    void setShield(double Shield);
    double getShield();

    void setSuper(double Super);
    double getSuper();

private:
    double shield;
    double super;

};

#endif