#include <string>

#include "monstermaker.h"

using namespace std;

double bossattack(double supper);

double bossdam(string name,string type,double damdone,double hp,double shield, super);

double damcalc(string name,string type,double damdone,double hp);

int main(){

    monstermaker goblin("goblin raider","blunt",1,10);


    cout<<"as you walk through the path to the town you see a small encampment"<<endl;
    cout<<"a goblin raider jumps out at you as you swing your sword and slash in his arm and do "<<damcalc()<<" damage"<<endl;
}

double damcalc(string name,string type,double damdone,double hp){
    double takendam;

    takendam = hp - damdone;

    return takendam;
}
double bossdam(string name,string type,double damdone,double hp,double shield,double super){
    double takedam;
    double shield;
    
    if(shield == 0){
        shield = damdone;
        return hp,shield;
    }
    else{
        takedam = hp - damdone;
        return takedam;
    }
}
double bossattack(double supper){
    double damdone;

    damdone = super;
}
