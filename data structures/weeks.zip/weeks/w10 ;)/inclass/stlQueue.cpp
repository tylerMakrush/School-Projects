#include <iostream>
#include <iomanip>
#include <math.h>
#include <string>
#include <queue>
#include <map>
#include <vector>
#include <time.h>
#include <cmath>

using namespace std;

void quelecture()
{
    queue<string> direction;
    string astep;
    int count = 0;

    direction.push("head up the oven");
    direction.push("mix ingedieounts");
    direction.push("pour into pan");
    direction.push("bake undil done");

    // while(!direction.empty()){
    // astep = direction.front();
    // direction.pop();
    // cout<<"step "<<""<<astep<<endl;
    // count++;
    // }
}
void vectorlecture()
{
    // vector is an unlimited sie array
    // array will size ittself as needed
    vector<int> numbervec;
    srand(time(NULL));
    double vecsize = (int)(rand() % 5000) + 1000;

    cout << "vector size is " << vecsize << endl;

    for (int x = 0; x < vecsize; x++)
    {
        numbervec.push_back(rand() % 5000);
        // number vec
    }
    // walks hrou the vector
    //show the efirst 10
    vector<int>::iterator itr;

    for(itr = numbervec.begin();itr != numbervec.begin()+10;itr++){
        cout<<*itr<<endl;
        
    vector<int> couter;
    couter[*itr] ++;
    }

}
void maplecture(){
    //like a dictonary key value pare
    //key must be unique
    //key is a 0(1) search
        //key    value 
    map<string, double> gradepoint;
    gradepoint["A+"] = 4.25;
    gradepoint["A"] = 4.0;
    gradepoint["A-"] = 3.75;

    cout<<"a is worth "<<gradepoint["A"]<<endl;
    cout<<"b is worth "<<gradepoint["b"]<<endl;
}

int main()
{

    //quelecture();
    //vectorlecture();
    maplecture();

    return 0;
}