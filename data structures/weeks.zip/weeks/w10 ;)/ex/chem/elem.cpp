#include "elem.h"

elem::elem()
{

}
elem::elem(string Name,char Symbol,int Atomnum,double Atomweight,
    double Meltpoint,double Boilpoint, double Atomradius){
        name = Name;
        symbol = Symbol;
        atomnum = Atomnum;
        atomweight = Atomweight;
        meltpoint = Meltpoint;
        boilpoint = Boilpoint;
        atomradius = Atomradius;
    }
elem::~elem()
{

}
void  elem::setName(string Name){
    name = Name;
}
string elem::getName(){
    return name;
}
void elem::setSymbol(char Symbol){
    symbol = Symbol;
}
char elem::getSymbol(){
    return symbol;
}
void elem::setAtomnum(int Atomnum){
    atomnum = Atomnum;
}
int elem::getAtomnum(){
    return atomnum;
}
void elem::setAtomweight(double Atomweight){
    atomweight = Atomweight;
}
double elem::getAtomweight(){
    return atomweight;
}
void elem::setMeltpoint(double Meltpoint){
    meltpoint = Meltpoint;
}
double elem::getMeltpoint(){
    return meltpoint;
}
void elem::setAtomradius(double Atomradius){
    atomradius = Atomradius;
}