#include <iostream>
#include <iomanip>
#include <math.h>
#include <string>
#include <fstream>
#include <forward_list>
#include <iterator>
#include <algorithm>

#include "elem.h"


using namespace std;

void filldata(forward_list<elem> data){
ifstream fin;

fin.open("elementdata.txt");
if(fin.fail()){
    cout<<"failed to open please check your files"<<endl;
}
while(!fin.eof()){
    for(){

    }
}

}
int main(){
    forward_list<elem> data;

   return 0; 
}