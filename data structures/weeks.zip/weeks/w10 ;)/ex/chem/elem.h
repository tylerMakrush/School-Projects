#ifndef ELEM_H
#define ELEM_H
#include <string>

using namespace std;

#pragma once

class elem
{
public:
    elem();
    elem(string Name,char Symbol,int Atomnum,double Atomweight,
    double Meltpoint,double Boilpoint, double Atomradius);
    ~elem();
    void setName(string Name);
    string getName();

    void setSymbol(char Symbol);
    char getSymbol();

    void setAtomnum(int Atomnum);
    int getAtomnum();

    void setAtomWeight(double Atomweight);
    double getAtomweight();

    void setMeltpoint(double Meltpoint);
    double getMeltpoint();

    void setBoilpoint(double Boilpoint);
    double getBoilpoint();

    void setAtomradius(double Atomradius);
    double getAtomradius();
    
private:
string name;
char symbol;
int atomnum;
double atomweight;
double meltpoint;
double boilpoint;
double atomradius;
};

#endif