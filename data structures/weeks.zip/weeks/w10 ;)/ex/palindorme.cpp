#include <iostream>
#include <iomanip>
#include <math.h>
#include <string>
#include <fstream>
#include <forward_list>
#include <iterator>
#include <algorithm>

using namespace std;

int fillList()
{
    char letter;
    forward_list<char> userinput;
    while (letter != '0')
    {
        // gets the users word
        cout << "please spell out the word when done enter 0"<< endl;
        cin >> letter;
        userinput.push_front(letter);
    }

    return 0;
}
int displaylist(forward_list<char> userinput)
{
    forward_list<char>::iterator letter;
    int count = 0;
    // displays it "forwared"
    for (letter = userinput.begin(); letter != userinput.end();)
    {

        cout << *letter << endl;

        count++;
        letter++;
    }
    
    // display backwards
    for (letter = userinput.end(); letter != userinput.begin();)
    {

        cout << *letter << endl;
        letter = userinput.end()-1;
    }

    if (count > 10)
    { // counts the size of the users word
        cout << "wow thats a big one :)" << endl;
    }
}

int main()
{

    forward_list<char> userinput;

    fillList();
    displaylist();

    return 0;
}