#ifndef SETPROB_H
#define SETPROB_H
#include <string>

#pragma once

using namespace std;

class setProb
{
public:
    setProb();
    setProb(int Rank, string Author,string Book,double Year);
    ~setProb();

    void setRank(int Rank);
    int getRank();

    void setAuthor(string Author);
    string getAuthor();

    void setBook(string Book);
    string getBook();

    void setYear(double Year);
    double getYear();


private:
int rank;
string author;
string book;
double year;

};

#endif