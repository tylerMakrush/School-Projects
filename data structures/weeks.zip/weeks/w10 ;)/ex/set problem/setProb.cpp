#include "setProb.h"

setProb::setProb()
{

}
setProb::setProb(int Rank, string Author,string Book,double Year){
    rank = Rank;
    author = Author;
    book = Book;
    year = Year;
}
setProb::~setProb()
{

}
//getters and setters
void setProb::setRank(int Rank){
    rank = Rank;
}
int setProb::getRank(){
    return rank;
}
void setProb::setAuthor(string Author){
    this->author = Author;
}
string setProb::getAuthor(){
    return author;
}
void setProb::setBook(string Book){
    this->book = Book;
}
string setProb::getBook(){
    return book;
}
void setProb::setYear(double Year){
    year = Year;
}
double setProb::getYear(){
    return year;
}