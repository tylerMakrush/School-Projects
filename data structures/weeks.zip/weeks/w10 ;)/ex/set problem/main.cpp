#include <iostream>
#include <iomanip>
#include <math.h>
#include <string>
#include <queue>
#include <map>
#include <vector>
#include <time.h>
#include <cmath>
#include "setProb.h"

using namespace std;

//fill array
int filldata(){
    
}

int main(){
    
}