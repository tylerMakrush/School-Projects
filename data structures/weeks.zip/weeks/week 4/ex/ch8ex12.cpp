#include <iostream>
#include <iomanip>
#include <math.h>
#include <string>
#include <fstream>
#include <string.h>
#include <algorithm>
#include <cmath>

using namespace std;

#define DIST 35
#define NAME 5

double data[NAME][DIST];

int fillArray();
double calcAvrage();

int main(){


  
    cout<<"the averages are "<<calcAvrage()<<endl;
    
    return 0;
}

int fillArray(){
    ifstream fin;
    int row;
    string aname;
    double adict;
    string runner[5];

    fin.open("ex12.data");

    if(fin.fail()){
        cout<<"ya file done goofed up"<<endl;
        return -1;
    }

    while(!fin.eof() && row < NAME){
        fin>>aname;
        runner[row] = aname;
        for(int g = 0; g < DIST; g++){
            fin>>adict;
            data[row][g] = adict;
        }
        row++;
    }
    return row;
}

double calcAvrage(){
    int rowav = 0;
    int overav = 0;

    for(int row =0; row < NAME; row++){

        for(int col = 0; col < DIST; col++){
        rowav += data[row][col];
        }
    overav[row] = (double) rowav / DIST;

    }
}