#include <iostream>
#include <iomanip>
#include <math.h>
#include <string>
#include <fstream>
#include <string.h>
#include <algorithm>
#include <cmath>

using namespace std;

void keeperOFRow(string user,int x);

void keeperOfSeat(string ussea,int x);

string row[13] = {"1","2","3","4","5","6","7","8","9","10","11","12","13"};
string seat[6] = {"*","*","*","*","*","*"};

int main(){
    string user;
    string ussea;
    int x;

    cout<<"enter the class of your ticket"<<endl;
    cin>>user;
    cout<<"please enter the seat you would like"<<endl;
    cin>>ussea;
}
void keeperOFRow(string user,int x){
    if(){

    }
    else{
        cout<<"error please try again relode the program"<<endl;
    }
}
void keeperOfSeat(string ussea, int x){
    

    seat[x] = "X";
}