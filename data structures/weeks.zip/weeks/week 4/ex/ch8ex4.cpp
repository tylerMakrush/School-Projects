#include <iostream>
#include <iomanip>
#include <math.h>
#include <string>
#include <fstream>
#include <string.h>
#include <algorithm>
#include <cmath>

using namespace std;
ifstream fin;

int score[];

int fillArray();

int main(){
   fin.open("test.txt");

  
  
}
int fillArray(){
    int col;

 if(fin.fail()){
       cout<<"ya done goofed file no workie";
       return -1;
   } 

    while(!fin.eof(); int x){
        score[x] = col;

        x++;

    }
}