#include <iostream>
#include <iomanip>
#include <math.h>
#include <string>
#include <fstream>
#include <string.h>
#include <algorithm>
#include <cmath>

#define SIZE 1000

//#define aargh cout; DONT THIS MAKE ME MAD BUT WORKS

using namespace std;

  int numbers[1000];



  void fillArrayFile(string path);

  void calcAvrage(int &avg);

  double calcstd(int avrage);
    


int main(){
    //data type variable [size];
    int avrage;
    fillArrayFile("numbers.txt");
    calcAvrage(avrage);
    cout<<avrage<<" avrage of array "<<endl;
    int std;

    std = calcstd(avrage);
    return 0;
}

void fillArrayFile(string path){
    int index = 0;
    ifstream fin;
    fin.open(path);

    
    if(fin.fail()){
        cout<<path<<"didnot open"<<endl;
    
    exit(-1);//die out
    }

    //(!fin.eof()){
    for(index = 0; index < 1000; index++){  

        //cout<<index<<endl;
        fin>>numbers[index];
    }
    cout<<index<<" numbers from "<<path<<endl;

}
 void calcAvrage(int &avg){
     int total = 0;

     for(int x=0; x < SIZE; x++){
         total += numbers[x];
     }
    avg = total/SIZE;
 }

  double calcstd(int avrage){
    double std = 0;
    double total;

    for(int x=0; x < SIZE; x++){
        
        total += pow(numbers[x] - avrage ,2);

    }
    std = sqrt(total / SIZE);
      return std;
  }