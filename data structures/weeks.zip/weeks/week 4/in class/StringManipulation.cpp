#include <iostream>
#include <iomanip>
#include <math.h>
#include <string>
#include <fstream>
#include <string.h>// need for strcopy and other functions
#include <algorithm>

using namespace std;

int main(){

    /*
    old school c++ string is an array of chars
    char name[] = "lee"; //l e e \0
    char *fname = new char[11];
    */

//    char name[] = "Tyler ";

//     strcpy(name,"rain");

//     // in vs stcpy_s(name, 4 "rain");

//    cout<<"hi "<<name<<endl;

   // new chool strings 

   string word = "hi";
   
//    if(word == "hi"){
//        cout<<"hi back"<<endl;

//    }
   string sentence = "four score and seven years ago";
    int pos = 0;
    pos = sentence.find("and");
    cout<<"and is a position "<<pos<<endl;

    //replace e with 3

    // keep replaceing until out of e's
    /*
    while(pos = sentence.find("e") != string::npos){
        sentence.replace(pos, 1,"3");
    }
    */

    //STL - standerd template library
    replace(sentence.begin(),sentence.end(),'e','3');

    cout<<sentence<<endl;

    //tokeniz the string
    char *theString = new char [sentence.length() + 1];
    strcpy(theString , sentence.c_str());
    
    char *token;
    char *nextToken;

    token = strtok_s(theString, " ",&nextToken);

    while(token != NULL){
        cout<<token<<endl;
        token = strtok_s(NULL," ",&nextToken);
    }

    return 0;
}