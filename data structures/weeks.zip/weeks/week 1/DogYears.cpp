#include <iostream>
#include <iomanip>
#include <math.h>
#include <string>

using namespace std;

int main() {

    int age = 52;
    int dogAge;
    string yourName;
    cout << "enter your name";
    cin >> yourName;

    //clear out new line in yyboard buffer
    cin.ignore(1000, '\n');
    cin.clear();

    cout << "your age is " << age << endl;
    cout <<"your age is " <<age<<endl;
    cout<<"your age in do years is " <<dogAge<<endl;

    return 0;

}