#include <iostream>
#include <math.h>
#include <iomanip>

using namespace std;

int main(){
    
}