#include <iostream>
#include <math.h>
#include <iomanip>

using namespace std;

int main(){
    double milkL = 0;
    double profit = 0;
    double cost = 0;

    cout<<"please enter the amount of lieters of milk produced"<<endl;
    cin>>milkL;

    cost = (milkL * 3.78) / 0.38;
    profit =(milkL * 3.78) *0.27;
    
    cout<<"the total cost of the milk was "<<cost<<endl;
    cout<<"the total profit was " <<profit<<endl;

    return 0;
}