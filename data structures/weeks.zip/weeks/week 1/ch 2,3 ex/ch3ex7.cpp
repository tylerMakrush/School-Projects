#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>

using namespace std;

int main(){
    double d1;
    double d2;
    double netbalance;
    double intrestperm;
    double dailyB;
    double pay;
    double intrestrate;

    cout<<"please enter your net balence"<<endl;
    cin>>netbalance;
    cout<<"enter the number of days in the biling cycles"<<endl;
    cin>>d1;
    cout<<"plese enter the number of days made before the payment"<<endl;
    

    dailyB = (netbalance*d1 - pay *d2) / d1;

    intrestrate = dailyB * 0.0152;
    
    cout<<"the daily balence is "<<dailyB<<endl;
    cout<<"and the intrest rate is "<<intrestrate<<endl;

    return 0;
}