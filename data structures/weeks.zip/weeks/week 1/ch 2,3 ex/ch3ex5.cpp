#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>

using namespace std;

int main(){
    string fname;
    string lname;
    double salary;
    double payin;
    double final;

    ifstream fin;
    fin.open("Ch3_Ex5Data.txt");
    if(fin.fail()){
        cout<<"file no there:(";
        return -1;       
    }
    while (!fin.eof())
    {
        cout<<"first name" <<fname;
        cout<<"last name "<<lname;
    }
    
    
}