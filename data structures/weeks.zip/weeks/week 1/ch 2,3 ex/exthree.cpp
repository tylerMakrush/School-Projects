#include <iostream>
#include <math.h>
#include <iomanip>

using namespace std;

int main()
{

    int num1 =  0;
    int num2 = 0;
    int num3 = 0;

    int av = 0;

    cout<<"please enter the first number "<<endl;
    cin >>num1;
    cout <<"please enter the second number"<<endl;
    cin>>num2;
    cout<<"please enter the last number"<<endl;
    cin>>num3;

    cin.ignore(1000, '\n');
    cin.clear();

    
    av = (num1 + num2 + num3 / 3);

    cout <<"the avrage number is......... " << av<<endl;
    
    return 0;

}