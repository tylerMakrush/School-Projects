#include <iostream>
#include <iomanip>
#include <math.h>

using namespace std;

int main()
{
    double num1 =0;
    double num2 =0;
    double num3 = 0;
    double num4 = 0;
    double num5 =0;
    double av = 0;

    cout <<"please enter the first score "<<endl;
    cin>>num1;
    cout<<"enter your second test "<<endl;
    cin>>num2;
    cout<<"enter your third test "<<endl;
    cin>>num3;
    cout<<"enter your forth number "<<endl;
    cin>>num4;
    cout<<"enter your final score "<<endl;
    cin>>num5;
    
    cin.ignore(1000, '\n');
    cin.clear();

    av = (num1 + num2 + num3 + num4 + num5) / 5;

    cout<<"the avrage score is "<<av<<endl;

    return 0;


}