#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>

using namespace std;

int calc(int income, double time, int rate);

int main(){
    int income;
    double time;
    int rate;

    cout<<"please enter your income"<<endl;
    cin>>income;
    cout<<"please enter the amount of time you worked with us"<<endl;
    cin>>time;
    cout<<"please enter the hourly rate"<<endl;
    cin>>rate;

    int p;
    
    p = calc(income,time,rate);

    return 0;
}

int calc(int income, double time, int rate){
    double bill = 0;
    if(income <= 25000 && time <= 30){
        bill = 0;
    }
    if(time <= 20){
        bill = 0;
    }
    if(income <= 25000){
        bill = rate * 40 * (time / 60.0);
    }
    else if(income >25000 && time > 20){
        bill = rate * 70 * (time / 60.0);
    }
    else{
        cout<<"error valid data needed"<<endl;
    }
    cout<<"your total bill is "<<bill<<"$"<<endl;

    return -1;
}