#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <string.h>
#include <algorithm>

using namespace std;

int main(){
    string user;

    cout<<"please provide the date"<<endl;
    cin>>user;
    
    char *theString = new char[user.length() + 1];

    strcpy(theString , user.c_str());

    char *token;
    char *nextToken;

    while(token != NULL){
        
        token = strtok_s(NULL, , &nextToken);
    }

    cout<<"the date is"<<endl;

    return 0;
}