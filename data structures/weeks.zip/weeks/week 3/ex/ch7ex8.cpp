#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>

using namespace std;

int incrypt(string user ,string password , string soc);

int main(string user ,string password , string soc){
    int p;

    cout<<"please enter a user name"<<endl;
    cin>>user;
    cout<<"please enter a passowrd"<<endl;
    cin>>password;
    cout<<"please enter your social security"<<endl;
    cin>>soc;

    p = incrypt(user,password,soc);
    
    return 0;
}

int incrypt(string user ,string password , string soc){
    string useren;
    string passworden;
    string socen;

    for(int c = 0; c < user.length();c++){
        useren += user.at(c) + "x";
    }
    for(int c = 0; c < password.length();c++){
        passworden += password.at(c) + "x";
    }
    for( int c = 0; c < soc.length();c++){
        socen += soc.at(c) + "x";
    }
    cout<<"user "<<useren<<endl;
    cout<<"pasword "<<passworden<<endl;
    cout<<"social security "<<socen<<endl;

    return 1;
}