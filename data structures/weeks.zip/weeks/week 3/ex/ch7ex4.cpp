#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <string.h>
#include <algorithm>
using namespace std;

int main(){
    char string[] = "";
    char *token;
    char *nextToken;

    cout<<"plese enter a word for me to remove all the vowls"<<endl;
    cin>>string[0,1,2];

while(token != NULL){
    if(token == 'a','e','u','o'){
        token = nextToken;
    }
    token = nextToken;
    }

    return 0;
}