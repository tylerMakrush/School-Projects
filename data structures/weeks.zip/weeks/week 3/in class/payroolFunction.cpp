#include <iostream>
#include <iomanip>
#include <math.h>
#include <string>

using namespace std;


//enum is just tnumbering system with costome names
//enumirations

enum year{jan, feb ,  mar , apr , may , jun , jul , aug , sep , oct, nov , dec};



//declare the function herer prototype prototype is just heder folowed by :
void prototype();
int somefunction(int x);
string buildAline(int size = 10);
// prototype and define the function at the same time
double grossPay(double hours,double rate){
    double pay = hours * rate;

}

//dry DONT REPET YOUR SELF


int main(){

    // CALL THE FUNCTION
    prototype();

    cout<<somefunction(3)<<endl;
    cout<<somefunction(10);
    
    int theAnswer = 0;

    cout<<" big numbers "<<theAnswer<<endl;
    cout<<buildAline()<<endl;
    cout<<buildAline(20)<<endl;
    
    for(int y = jan; y <= dec;y++){
    cout<<y<<endl;
}

    return 0;   
}

void prototype(){
    
    cout<<"tyler makrush"<<endl;
}

int somefunction(int x){

    return x * x;
}
string buildAline(int size = 10){
    string line;
    for (int x = 0; x < size;x++)
    {
    line +="-";
    }

    return line;
}