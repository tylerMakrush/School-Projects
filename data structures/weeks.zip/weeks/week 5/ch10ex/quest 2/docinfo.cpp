#include "docinfo.h"

docinfo::docinfo()
{

}
docinfo::docinfo(std:: string Fname,std::string Lname,double Hight,double Weight){
    fname = Fname;
    lname = Lname;
    hight = Hight;
    weight = Weight;
}
docinfo::~docinfo()
{

}
void docinfo::setFName(std::string Fname){
    this->fname = Fname;
}
std::string docinfo::getFName(){
    return fname;
}
void docinfo::setLname(std::string Lname){
    this->lname = Lname;
}
std::string docinfo::getLname(){
    return lname;
}
void docinfo::setHight(double Hight){
    hight = Hight;
}
double docinfo::getHight(){
    return hight;
}
void docinfo::setWeight(double Weight){
    weight = Weight;
}
double docinfo::getWeight(){
    return weight;
}