#ifndef DOCINFO_H
#define DOCINFO_H
#include <string>

#pragma once

class docinfo
{
public:
    docinfo();
    docinfo(std:: string Fname,std::string Lname,double Hight,double Weight);
    docinfo();
    
    void setFName(std::string Fname);
    std::string getFName();

    void setLname(std::string Lname);
    std::string getLname();

    void setHight(double Hight);
    double getHight();

    void setWeight(double Weight);
    double getWeight();



private:
    std::string fname;
    std::string lname;
    double hight;
    double weight;

};

#endif