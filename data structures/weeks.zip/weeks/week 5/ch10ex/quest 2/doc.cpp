#include <iostream>
#include <iomanip>
#include <math.h>
#include <string>
#include <fstream>
#include <string.h>
#include <algorithm>
#include <cmath>


#include "docinfo.h"

using namespace std;

double calcbmi();

int main(){

        

   double calcbmi(); 

}

double calcbmi(double weight,double hight){
    double bmi;

    bmi = weight / hight;

    return bmi;
}