#include "sandwichmaker.h"

sandwichmaker::sandwichmaker()
{

}
sandwichmaker::sandwichmaker(string Bread,string Meat,string Cheese,
    double Cost){
        bread = Bread;
        meat = Meat;
        cheese = Cheese;
        cost = Cost;
    }
sandwichmaker::~sandwichmaker()
{

}
void sandwichmaker::setBread(string Bread){
    bread = Bread;
}
string sandwichmaker::getBread(){
    return bread;
}

void sandwichmaker::setMeat(string Meat){
    meat = Meat;
}
string sandwichmaker::getMeat(){
    return meat;
}
void sandwichmaker::setCheese(string Cheese){
    cheese = Cheese;
}
string sandwichmaker::getCheese(){
    return cheese;
}
void sandwichmaker::setCost(double Cost){
    cost = Cost;
}
double sandwichmaker::getCost(){
    return cost;
}
 double sandwichmaker::calcCost(){

     if(bread = "flat bread"){
         cost +=2.00;
     }
     if(bread = "italian"){
         cost += 1.00;
     }
     if(bread = "white bread"){
         cost 
     }
     else{
         cost += 0.00;
     }
     if(meat = "ham"){
         cost += 1.00;
     }
     
 }
