#ifndef SANDWICHMAKER_H
#define SANDWICHMAKER_H
#include <string>

#pragma once
    using namespace std;

class sandwichmaker
{
public:
    sandwichmaker();
    sandwichmaker(string Bread,string Meat,string Cheese,
    double Cost);
    ~sandwichmaker();

    void setBread(string Bread);
    string getBread();

    void setMeat(string Meat);
    string getMeat();

    void setCheese(string Cheese);
    string getCheese();

    void setCost(double Cost);
    double getCost();

    double calcCost();

private:
    string bread;
    string meat;
    string cheese;
    double cost;
};

#endif