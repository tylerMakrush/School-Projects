#ifndef CARCREAT_H
#define CARCREAT_H
#include <string>
#pragma once

using namespace std;

class carcreat
{
public:
    carcreat();
    carcreat(string Make,string Mod,double Year,double Mil,double Milage, double Gal,double Mpg);
    ~carcreat();

    inline void setMake(string Make){
        
    }
    string getMake();

    void setMod(string Mod);
    string getMod();

    inline double setYear(double Year){

    }// this can do all in one line set and get really fast give this a try do not delet this is valit tyler

    double getYear();

    double setMil(double Mil);
    double getMil();

    double setMilage(double Milage);
    double getMilage();

    double setGal(double Gal);
    double getGal();
    
    double setMpg(double Mpg);
    double getMpg();


    string to_string();

    double costPerMCalc();

    double distinceCalc();



private:

    string make;
    string mod;
    double year;
    double mil;
    double mpg;
    double milage;


};

#endif