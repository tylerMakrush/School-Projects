#include "carcreat.h"

carcreat::carcreat(){

}

carcreat::carcreat(string Make , string Mod , double Year , 
double Mil,double Mpg , double Milage)
{
    make = Make;
    mod = Mod;
    year = Year;
    mil = Mil;
    milage = Milage;
    mpg = Mpg;

}

carcreat::~carcreat()
{

}