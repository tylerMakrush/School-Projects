#include <string>

#include "monstermaker.h"

using namespace std;

double damcalc(string name,string type,double damdone,double hp);

int main(){

    monstermaker goblin("goblin raider","blunt",1,10);


    cout<<"as you walk through the path to the town you see a small encampment"<<endl;
    cout<<"a goblin raider jumps out at you as you swing your sword and slash in his arm and do "<<damcalc()<<" damage"<<endl;
}

double damcalc(string name,string type,double damdone,double hp){
    double takendam;

    takendam = hp - damdone;

    return takendam;
}