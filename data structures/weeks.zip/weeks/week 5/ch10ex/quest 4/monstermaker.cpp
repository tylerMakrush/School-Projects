#include "monstermaker.h"

monstermaker::monstermaker()
{

}
monstermaker::monstermaker(string Name,string Type,
double Damdone, double Hp){
    name = Name;
    type = Type;
    damdone = Damdone;
    hp = Hp;
}
monstermaker::~monstermaker()
{

}

void monstermaker::setName(string Name){
    name = Name;
}
string monstermaker::getName(){
    return name;
}

void monstermaker::setType(string Type){
    type = Type;
}
string monstermaker::getType(){
    return type;
}

void monstermaker::setDamdone(double Damdone){
    damdone = Damdone;
}
double monstermaker::setDamdone(){
    return damdone;
}

void monstermaker::setHp(double Hp){
    hp = Hp;
}
double monstermaker::getHp(){
    return hp;
}