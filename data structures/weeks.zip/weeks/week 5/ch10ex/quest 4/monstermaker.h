#ifndef MONSTERMAKER_H
#define MONSTERMAKER_H
#include <string>

#pragma once
using namespace std;
class monstermaker
{
public:
    monstermaker();
    monstermaker(string Name,string Type,double Damdone,double Hp);
    ~monstermaker();

    void setName(string Name);
    string getName();

    void setType(string Type);
    string getType();

    void setDamdone( double Damdone);
    double getDamdone();

    void setHp(double Hp);
    double getHp();

private:
    string name;
    string type;
    double damdone;
    double hp;
    
};

#endif