#include <iostream>
#include <iomanip>
#include <math.h>
#include <string>
#include <fstream>
#include <string.h>
#include <algorithm>
#include <cmath>

using namespace std;

#define STUD 10
#define GRADES 5

string student[STUD];
int grades[STUD][GRADES];
double avrage[STUD];

int fillArray()
{
    int row = 0;
    int aGrade;
    string aSTUD;
    ifstream fin;

    fin.open("ch8num13.data");

    if (fin.fail())
    {
        cout << "fould not open the file";
        return -1;
    }
    while (!fin.eof() && row < STUD)
    {
        fin >> aSTUD;
        student[row] = aSTUD;
        for (int g = 0; g < GRADES; g++)
        {
            fin >> aGrade;
            grades[row][g] = aGrade;
            // cout << row << " row " << g << " g " << aGrade << endl;
        }
        row++;
    }

    return row;
}

double calcAvrage()
{
    double classav = 0;
    double row = 0;
   // double rowAvg[STUD];
    int rowtotal = 0;
    int classtotal = 0;

    for (int row = 0; row < STUD; row++)
    {
        for (int col = 0; col < GRADES; col++)
        {
            rowtotal += grades[row][col];
        } // ends of col

        avrage[row] =  (double)rowtotal/GRADES;
        classtotal += rowtotal;
        rowtotal = 0;//resets the row total
    }     // ends of row

    classav = (float) classtotal / (GRADES * STUD);
    return classav;
}

void reportcard(){
    for(int s = 0; s < STUD; s++){
        cout<<setw(25)<<left<<student[s]<<avrage[s]<<endl;
    }
}

int main()
{
    int rowread = 0;

    rowread = fillArray();

    if (rowread <= 0)
    {
        cout << "problem with file" << endl;
        return -1;
    }
   cout<<"class avrage<< "<<calcAvrage()<<endl;

   reportcard();

    return 0;
}