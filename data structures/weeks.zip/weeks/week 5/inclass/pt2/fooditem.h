#ifndef FOODITEM_H
#define FOODITEM_H
#include <string>
#pragma once

using namespace std;

class fooditem
{
public:
    //tipically methods
    fooditem();//defalt constructo
    fooditem(string Name,int Calor,double Cost);
    ~fooditem();//destructor
    \
    void setName(string Name);
    string getName();

    void setCalor(int Calor);
    int getCalor();

    void setCost(double Cost);
    double getCost();

string to_string();

double perCalorCost();

private:
    //varianbles

    string name;
    int calor;
    double cost;

protected:

};

#endif