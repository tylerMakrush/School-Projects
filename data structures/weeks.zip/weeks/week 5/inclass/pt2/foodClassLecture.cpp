#include <iostream>
#include <iomanip>
#include <math.h>
#include <string>
#include <fstream>
#include <string.h>
#include <algorithm>
#include <cmath>

#include "fooditem.cpp"//including the file

using namespace std;

int main(){

    fooditem drink;
    fooditem cookies("oreose",100,2.4);

    drink.setName("coke");
    drink.setCalor(100);
    drink.setCost(20.99);

    cout<<drink.to_string()<<endl;

    double totalCost = drink.getCost() + cookies.getCost();

    return 0;
}