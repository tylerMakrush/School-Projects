#include "fooditem.h"

fooditem::fooditem()
{
    name = "";
    calor = 0;
    cost = 0;
}
fooditem::fooditem(string Name,int Calor,double Cost){
    name = Name;
    calor = Calor;
    this->cost = Cost;
}
fooditem::~fooditem()
{

}
//setters and getters

void fooditem::setName(string Name){
    this->name = Name;
}
string fooditem::getName(){

    return name;
}

void fooditem::setCalor(int Calor){
    calor = Calor;
}
int fooditem::getCalor(){
    return calor;
}
void fooditem::setCost(double Cost){   
    cost = Cost;

}
double fooditem::getCost(){
    return cost;
}
string fooditem::to_string(){
    return name + " caloris " + std::to_string(calor)
     + " cost " + std::to_string(cost);
}

double fooditem::perCalorCost(){
    
    return cost / calor;
}