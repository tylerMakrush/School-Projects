#include <iostream>
#include <iomanip>
#include <math.h>
#include <string>

using namespace std;

int main(){
    int num = 0;
    int total = 0;
    int digit = 0;
    int count = 0;

    cout<<"plese ener one of the examle numbers 75,111,678,732,873,2048, and 65535"<<endl;
    cin>>num;
    while(num > 0);{
        digit = num % 10;
        num = num / 10;
    }
    if(count % 2 == 0){
        total = digit;
        count++;
    }
    cout<<"total"<<total<<endl;
}