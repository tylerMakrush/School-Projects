#include <iostream>
#include <iomanip>
#include <math.h>
#include <string>

using namespace std;

//i am getting a paused on something when i run the program

int main(){

    int roomsR = 0;
    int numDay = 0;
    int f = 0;
    
    cout<<"plese enter the amount of rooms that you will enter the number of roomds being rented"<<endl;
    cin>>roomsR;
    cout<<"plese enter the number of day you will be staying"<<endl;
   cin>>numDay;

   f = 100 * f;

   //percent discount calc
if(roomsR > 29){
    f = (f * 30) - f;
}
if(roomsR > 19){
    f =(f * 20) - f;
}
if(roomsR > 9){
    f = 20 % f;
}
//time discount
if(numDay < 4){
    f = (f * 5) - f;
}
   cout<<"your total is "<<f<<endl;
   
    return 0;
}