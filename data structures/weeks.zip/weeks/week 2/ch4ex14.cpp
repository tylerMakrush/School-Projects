#include <iostream>
#include <iomanip>
#include <math.h>
#include <string>

using namespace std;

int main(){
    double f;
    double h;

    //get user in
    cout<<"plese tell me how long you intend on taking up my space..."<<endl;
    cin>>h;

    //calculations 
    if(0 < h < 3){
        f = 5 * int(h + 1);
    }
    else if(3 < h < 9){
        f = 6 * int(h + 1);
    }
    else if(9 <h <24){
        f = 60 * int(h + 1);
    }

    //error message and the end
    else{
        cout<<"an error occured"<<endl;
    }
    cout<<"and your total for parking is "<<f<<endl;

        return 0;


}