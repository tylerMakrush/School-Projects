#include <iostream>
#include <iomanip>
#include <math.h>
#include <string>

using namespace std;

int main(){
    int a;
    int b;
    int t;
}