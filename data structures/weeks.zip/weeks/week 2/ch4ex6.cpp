#include <iostream>
#include <iomanip>
#include <math.h>
#include <string>

using namespace std;

int main(){
    int cookies = 0;
    int boxes = 24;
    int numbox = 0;
    int continers = 75;
    int numcon = 0;
    int excook = 0;

//gets num of cookies
    cout<<"please tell us how many cookies you want "<<endl;
    cin>>cookies;


    numbox = cookies / boxes;

    numcon = numbox / continers;
        if(numbox != 0)
        numcon++;

    cout<<"the number of boxes you will need is "<<numbox<<endl;

    cout<<"the number of containers you will need is "<<numcon<<endl;



    return 0;
}