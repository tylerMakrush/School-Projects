#include <string>
#ifndef DATASTORE_H
#define DATASTORE_H

using namespace std;

#pragma once

class datastore
{
public:
    datastore();
    datastore(int Id, string Fname,string Lname,string Email,
    string Gender,double Ip);
    ~datastore();
    //setters and getters
    void setId(int Id);
    int getId();
    
    void setFname(string Fname);
    string getFname();

    void setLname(string Lname);
    string getLname();

    void setEmail(string Email);
    string getEmail();

    void setGender(string Gender);
    string getGender();

    void setIp(double Ip);
    double getIp();

    string to_string();

    friend ostream& operator<<(ostream &out, const datastore &item);
	friend istream &operator>>(istream &in, datastore &item);

private:
int id;
string fname;
string lname;
string email;
string gender;
double ip;
};

#endif