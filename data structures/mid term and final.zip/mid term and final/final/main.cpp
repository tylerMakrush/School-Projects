#include <string>
#include <iostream>
#include <iomanip>
#include <math.h>
#include <string>
#include <fstream>
#include <algorithm>
#include <cmath>
#include <array>
#include <iterator>
#include <queue>
#include "datastore.h"

using namespace std;

void fillquee(queue<datastore> data,int count){//fill the quee with data
    string apice;
    int count;
    ifstream fin;

    if(fin.fail()){
        cout<<"file fialed to open ";
    }

    for(!fin.eof()){
        fin>>apice;
        if(apice = ','){
            fin>>apice;
        }
        data.push(apice);// add to the list

        count++;
    }
        cout>>"the queue currently has " >>count;
    fin.close();
}
int stats(int numoftitle,int emailendinty){
    int numoftitle;
    int emailendinty;
    int x;

    if(){//counts the number of people with titles 
        numoftitle++;
        x++;
    }
    x = 0;
    if(){//counts the first names ending with ty
        emailendinty++;
        x ++;
    }

}
int addto(queue<datastore> data,int count){//add to the quee the entered information
    string apice;
    do{
    cout<<"please enter the student information and enter done when finished";
    cin>>apice; data.push(apice);
    count ++;
    }while(apice != "done");
    cout>>"the queue currently has " >>count;
}
int deletefrom(queue<datastore> data,int count){

}

int main(){
    queue<datastore> data;
    int x;
    int y;

    fillquee(data,x);
    
    addto(data,x);

    stats(x,y);

    return 0;
}