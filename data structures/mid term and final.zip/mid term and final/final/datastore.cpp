#include "datastore.h"

using namespace std;

datastore::datastore()
{

}
datastore::datastore(int Id, string Fname,string Lname,string Email,
    string Gender,double Ip){
        id = Id;
        fname = Fname;
        lname = Lname;
        email = Email;
        gender = Gender;
        ip = Ip;

}
datastore::~datastore()
{

}
void datastore::setId(int Id){
    id = Id;
}
int datastore::getId(){
    return id;
}
void datastore::setFname(string Fname){
    fname = Fname;
}
string datastore ::getFname(){
    return fname;
}
void datastore::setLname(string Lname){
    lname = Lname;
}
string datastore::getLname(){
    return lname;
}
void datastore::setEmail(string Email){
    email = Email;
}
string datastore::getEmail(){
    return email;
}
void datastore::setGender(string Gender){
    gender = Gender;
}
string datastore::getGender(){
    return gender;
}
void datastore::setIp(double Ip){
    ip = Ip;
}
double datastore::getIp(){
    return ip;
}
//overload
string datastore::to_string(){
    return "id" + std::to_string(id) + " the students first name is" + fname + 
    " the students last name is " + lname + " the students email is " + email + 
    " the students gender is " + " and the ip is " + std::to_string(ip);
}
istream &operator>>(istream &in, datastore &item){
    cout<<" please enter the id";
    in>>item.id;

    return in;
}
ostream &operator<<(ostream &out, const datastore &item){


    return out;
}

