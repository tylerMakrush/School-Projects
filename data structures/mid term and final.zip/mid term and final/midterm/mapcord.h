#ifndef MAPCORD_H
#define MAPCORD_H
#include <string>

#pragma once

using namespace std;

class mapcord
{
public:
    mapcord();
    mapcord(string Name, double Lat, double Lon);
    ~mapcord();

    void setName(string Name);
    string getName();

    void setLat(double Lat);
    double getLat();

    void setLon(double Lon);
    double getLon();
    
    string to_string();

private:
    string name;
    double lat;
    double lon;

};

#endif