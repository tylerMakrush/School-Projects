#include "mapcord.h"

using namespace std;

mapcord::mapcord()
{
name = "";
lat = 0.0;
lon = 0.0;
}
mapcord::mapcord(string Name, double Lat, double Lon){
    name = Name;
    lat = Lat;
    lon = Lon;
}
mapcord::~mapcord()
{

}
void mapcord::setName(string Name){
    this->name = Name;
}
string mapcord::getName(){
    return name;
}
void mapcord::setLat(double Lat){
    lat = Lat;
}
double mapcord::getLat(){
    return lat;
}
void mapcord::setLon(double Lon){
    lon = Lon;
}
double mapcord::getLon(){
    return lon;
}
string mapcord::to_string(){
    return " the locations name is " + name + " wich is " + lat + " degrees nourth or south and " + 
    lon + " degrees east or west";
}