#include <iostream>
#include <iomanip>
#include <math.h>
#include <string>
#include <fstream>
#include <string.h>
#include <algorithm>
#include <cmath>

#include "mapcord.h"
#ifndef MAPCORD_H
#define MAPCORD_H
#define ITEM 4


using namespace std;

double calcav(double arr[]);

mapcord place[ITEM];

void fillmap(){
    place[0] = mapcord("verdun",50.5,50.5);
    place[1] = mapcord("normandy",20.2,20.2);
    place[2] = mapcord("flandersfields",10.1,10.1);

    int x = 0;

    do{
        cout<<place[x].getName() << place[x].getLat() << place[x].getLon<<endl;
        x++;
    }while(x < ITEM);
}

int main(){
    double arr[] = {4.5,6.7,2.3,4.9,2,11.5,13.9,3.5,1.1,0.9,12.3,6.96};
    
    cout<<calcav()<<endl;
    fillmap();
  

}double calcav(double arr[]){
    int num = 0;
    double sum = 0;
    double av = 0;
    double indav;

    while(num < 15){
        sum += arr[num];
        num++;
    }
    num = 0;

    while(num < 15){
        indav = av = arr[num];

        cout<<arr[num]<<" and the diffrence is "<<indav<<endl;
        
        if(num > 5){
            cout<<"wooow thats a big number"<<endl;
        }
        if(num < -5){
            cout<<"thats a small number"<<endl;
        }
        indav = 0;
    }
    av = av / 15;

    return av;
}