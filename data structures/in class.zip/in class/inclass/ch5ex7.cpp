#include <iostream>
#include <iomanip>
#include <math.h>
#include <string>

using namespace std;

int main(){
    int num = 8784204;
    int total = 0;
    int digit = 0;
    int count = 0;

    cout <<"number is"<< num << endl;
    while( num > 0);{
        digit = num % 10;
        num = num /10;
        cout << digit << endl;
        
        if(count % 2 == 0){
            total = digit;
        }
        else{
            total = digit;    
        }
        count++;
    }
    cout<<"total"<<total<<endl;

}