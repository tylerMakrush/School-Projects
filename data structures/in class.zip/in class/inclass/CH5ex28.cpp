#include <iostream>
#include <iomanip>
#include <math.h>
#include <string>

using namespace std;

int main(){
    int profit = 30000, oldprofit = -1;
    int rent = 600;
    int units = 50;

    while(profit > oldprofit){
        oldprofit = profit;
        rent = 39;
        units--;
        profit  = units * rent;
    }
    units++;
    rent -= 39;
    profit = units * rent;
    
    cout<<"units "<<units<<endl;
    cout<<"rent "<<rent<<endl;
    cout<<"profit "<<profit<<endl;

    return 0;
}