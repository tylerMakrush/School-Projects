#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>

using namespace std;

int main(){
    int hits , atbats, walks;
    
    double batav;

    ifstream fin;
    fin.open("stats.txt");
    if(fin.fail()){
        cout<<"file not open stats.txt not found :(";
        return -1;
    }

    hits = atbats = walks = 0;
while (!fin.eof()){

{
    /* code */
}

fin>>atbats >>hits>>walks;
// //input
// cout << " enter the atbats ";
// cin>> atbats;
// cout <<" enter the hits ";
// cin >>hits;
// cout<<" enter the walks ";
// cin>>walks;

// //proccess

 batav = hits /static_cast<double> (atbats - walks);

 //echo out the output
 cout <<"at the bats "<< atbats<<endl;
 cout <<" hits "<<hits<<endl;
 cout<<"walks "<<hits<<endl;
cout<<"bat avg "<<setprecision(3)<<fixed<<batav<<endl;
}
fin.close();
    return 0;
}