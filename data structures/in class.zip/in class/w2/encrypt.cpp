#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>

using namespace std;

    /*
    open the file 
    walk through the file(parse)
    encrypt the letters
    write the encryption ou to a ful e
    close the file
    */

int main(){
    string line;
    string encrypted;
    ifstream fin;
    ofstream fout;
    int rotation = 5;

    // open the file
    fin.open("frost.txt");
    if(fin.fail()){
        cout<<"frost.txt not opeaned :(";
        return -1;
    }
    fout.open("frost.enc");
    if(fout.fail()){
        cout<<"frost.enc failed to open:("<<endl;
        return -2;
    }
    while (getline(fin, line))
    {
        /* keep looping as long as their are lines in the file*/
        //cout<<line<<endl;
        encrypted = "";// clear out the encryption
        for(int c=0; c < line.length(); c++){
            encrypted += line.at(c) + rotation;
        }
        fout<<encrypted<<endl;
    }

    fout.close();
    fin.close();
    

    return 0;
}