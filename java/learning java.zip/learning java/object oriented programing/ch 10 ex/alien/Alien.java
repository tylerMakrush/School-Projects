

public class Alien{
    protected int hight;
    protected int numLegs;
    protected int numEyes;

public Alien(int ht,int legs,int eye){
    hight = ht;
    numLegs =legs;
    numEyes = eye;
}
public String toString(){
    String message;
    message = "Alien hight is " + hight + " feet " + "\n it has " + numLegs + 
    " legs and " + numEyes + " eyes.";
    return message;
 }
}