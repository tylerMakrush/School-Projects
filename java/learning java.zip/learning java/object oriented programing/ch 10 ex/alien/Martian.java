import javax.swing.*;
import java.awt.*;

public class Martian extends Alien {
    
    public Martian(){
        super(7, 3, 5);
    }

}
