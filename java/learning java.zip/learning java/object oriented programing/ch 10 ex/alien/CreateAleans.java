public class CreateAleans {
    public static void main(String[] args) throws Exception {
       
        Martian aMartian = new Martian();
        Jupiterian aJupiterian = new Jupiterian();

        System.out.println("martian " + aMartian.toString());
        System.out.println("Jupertarian " + aJupiterian.toString());
    }
}
