public class candle {
    public String colour;
    public String hight;
    public double price;
}