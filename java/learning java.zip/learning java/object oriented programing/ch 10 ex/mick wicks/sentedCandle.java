public class sentedCandle extends candle {
    
    public sentedCandle("red", "4",)
}
