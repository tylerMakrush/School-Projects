public class horse{
    private String name;
    private String colour;
    private double birth;
}