public class raceHorse extends horse {

    public raceHorse()
    {
        super("ol bessie", "purdy pink",10 );
    }
    
}
