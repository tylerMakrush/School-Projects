public class demoHorse {
    public String n;
    public String c;
    public double num;
}
public horse(String name, String colour,double birth)
{
    n = name;
    c = colour;
    num = birth;
}
public String toString()
{
    String message;
    message = "the horses name is " + n + " the horses colour is " + c + " the horses age is "
    + num;

}