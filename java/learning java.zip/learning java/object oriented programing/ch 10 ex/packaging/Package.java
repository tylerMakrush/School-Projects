public class Package 
{
    
    
    private int wieght;
    private char method;
    private double cost;
    final char AIR = 'A';
    final char TRUCK = 'T';
    final int LOWWT = 9;
    final double LOWAIR = 2.00;
    final double LOWTRUCK = 1.50;
    final double LOWMAIL = 0.50;

    final int MEDWT = 17;
    final double MEDAIR = 3.00;
    final double MEDDTRUCK = 2.35;
    final double MEDMAIL = 1.50;
    
    final double HIGHTAIR = 4.50;
    final double HIGHTRUCK = 3.25;
    final double HIGHTMAIL = 2.15;

    public Package (int w, char m)
    {
        wieght = w;
        method = m;
        cost = calculateCost(w,m);
    }
    private double calculateCost ( int w, char m)
    {
        double c =0;
        if(w < LOWWT)
        {
            if(m==AIR)
            c = LOWAIR;
            else
                if(m == TRUCK)
                c = LOWTRUCK;
                else 
                    c = LOWMAIL;
        }
        return c;
    }
    public void display()
    {
        System.out.println("the pachage weighs " + wieght + " pounds. the shipping method " 
        + method + " cost $ " + cost);
    }
    public double getCost(){
        return cost;
    }
    public void increaseCost(double c)
    {
        cost = cost + c;
    }
}
