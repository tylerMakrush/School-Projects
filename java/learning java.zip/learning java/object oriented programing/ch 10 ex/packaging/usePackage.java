public class usePackage {
    public static void main(String[] args) {
        
        Package p1 = new Package(4, 'A'), 
        p2 = new Package(10, 't'),
        p3 = new Package(20, 'm');

        InsuredPackage p4 = new InsuredPackage(4, 'A'),
        p5 = new InsuredPackage(10, 't'),
        p6 = new InsuredPackage(20, 'm');

        System.out.println("packages :");
        p1.display();
        p2.display();
        p3.display();
        System.out.println("insucured packages:");
        p4.display();
        p5.display();
        p6.display();
    }
}
