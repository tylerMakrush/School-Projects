import java.util.*;
public class tryToParseDouble{
public static void main(String[] args) {
    
    Scanner keyboard = new Scanner(System.in);
    double num = 0;

    try{
        System.out.println("");
    }
    catch(NumberFormatException error){

       num = 0;
       System.out.println("values entered cannot be converted to floation point number"); 
    }
    System.out.println("number is " + num);
}
}