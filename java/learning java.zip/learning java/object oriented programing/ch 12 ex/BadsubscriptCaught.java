import java.util.*;
public class BadsubscriptCaught{
    public static void main(String[] args) {
        String[] name = {"ty" , "james" ,"larry","jerry", "gerry" , "barry", "bill" , "saddy" ,"kass" ,"kim"};
        int num = 0;

        
        Scanner inputDevice = new Scanner(System.in);
        
        System.out.println("please enter the intigher that corisponds with your subscription ");

        num = inputDevice.nextInt();
        try{
            System.out.println("welcome " + name[num]);
        }
        catch(NumberFormatException error){
            System.out.println("error please enter valid information");
        }
    }
}