import javax.swing.*;

public class sqrtException {

    public static void main(String[] args) 
    {
        
        double num, result;
        String numString;

        numString = JOptionPane.showInputDialog(null, "enter a number");

        num = Integer.parseInt(numString);

        try{
            if(num < 0)
            {
                throw(new ArithmeticException());

                result = Math.sqrt(num);
                JOptionPane.showMessageDialog(null, "result is " + result);

                catch(ArithmeticException erro)
                {
                    JOptionPane.showMessageDialog(null, "you cannot take the square root of a negetive");
                }
            }
        }
    }
}
