import java.sql.Array;
import java.util.Scanner;
class MeanMedian {
    public static void main(String[] args) {

        int[] user = {1,2,3,4};
        int mean;


        Scanner inputDevice = new Scanner(System.in);
        System.out.println("please enter 4 numbers");

        user[0] = inputDevice.nextInt();
        user[1] = inputDevice.nextInt();
        user[2] = inputDevice.nextInt();
        user[3] = inputDevice.nextInt();

        mean = user[0] + user[1] + user[2] + user[3];

       

        System.out.println("the mean is ... " + mean);
        System.out.println("the ,median is ... " + user[2]);
    }

}