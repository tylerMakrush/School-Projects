public class Recording {
    public static void main(String[] args) {
        String artist;
        String song;
        int time;

    }
    public class music{
        String artist;
        String song;
        int time;

    }  
    public music(){
        
    }

    public String toString(){
        String message;

        message = "hello every one nexed up is " ;

        return message;
    }
}
