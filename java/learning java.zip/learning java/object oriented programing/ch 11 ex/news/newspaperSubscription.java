import java.util.concurrent.Flow.Subscriber;

public class newspaperSubscription{

    String subName;
    String address;
    String rate;
}