public abstract class book{
    String title = new String();
    double price;

    public book(String t){
        title = t;
    }

    public String getTitle(){
        return title;
    }
    public double getPrice(){
        return price;
    }

    public abstract void setPrice();
}