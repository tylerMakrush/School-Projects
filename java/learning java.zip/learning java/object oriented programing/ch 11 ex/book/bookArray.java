public class bookArray {
    
    public static void main(String[] args) {
        
        book somebBook[] = new book[10];
        
        somebBook[0] = new fiction("harry potter");
        somebBook[1] = new nonfiction("intro to java");

        for(int i = 0; i < somebBook.length; i++){

            System.out.println("book " + somebBook[i].getTitle() + "cost $" + somebBook[i].getPrice());
        }
    }
}
