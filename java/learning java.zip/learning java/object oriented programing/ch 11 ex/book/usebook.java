public class usebook {
    
    public static void main(String[] args) {
        
        fiction aNovel = new fiction("dune");
        nonfiction aManual = new
        nonfiction("elemants of style");

        System.out.println("fiction " + aNovel.getTitle() + " cost $" + aNovel.getPrice());
    
        System.out.println("non-fiction " + aManual.getTitle() + " cost $" + aManual.getPrice());
    }
}
