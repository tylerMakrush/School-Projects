public class nonfiction  extends book{
    
    public nonfiction(String title){
        super(title);
        setPrice();
    }

    public void setPrice(){
        super.price = 37.99;
    }
}
