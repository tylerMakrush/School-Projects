public class fiction extends book {
    
    public fiction(String title){
        super(title);
        setPrice();
    }

    public void setPrice(){
        super.price = 24.99;
    }
}
