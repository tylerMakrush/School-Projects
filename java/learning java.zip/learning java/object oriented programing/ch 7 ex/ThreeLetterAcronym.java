import java.util.Scanner;
public class ThreeLetterAcronym {
    public static void main(String[] args) {
        String ac;
        String acOut;
        int acNum;

        Scanner inputDevice = new Scanner(System.in);
        System.out.println("please enter an Acronym");
        ac = inputDevice.nextLine();
        acNum = ac.length();

        if(acNum == 3)
        {
            acOut = ac.toUpperCase();

            System.out.println(acOut);
        }

        else{
            System.out.println("please enter a valad acronem");
        }

    }
}
