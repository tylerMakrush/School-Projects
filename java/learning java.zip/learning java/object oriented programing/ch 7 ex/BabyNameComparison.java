import java.util.Scanner;
public class BabyNameComparison {
    public static void main(String[] args) {
        
        String name1;
        String name2;
        String name3;

        Scanner inputDevice = new Scanner(System.in);

        System.out.println("please provide a name --->");
        name1 = inputDevice.nextLine();

        System.out.println("please provide a nother name --->");
        name2 = inputDevice.nextLine();

        System.out.println("please provide one final name --->");
        name3 = inputDevice.nextLine();


        System.out.println(name1 +" "+ name2);

        System.out.println(name1 +" "+ name3);

        System.out.println(name2 +" "+ name1);

        System.out.println(name2 +" "+ name3);

        System.out.println(name3 +" "+ name1);

        System.out.println(name3 +" " + name2);


    }
}