import java.util.Scanner;
public class ValifatePassword {
    public static void main(String[] args) 
    {
        String password;
        
        Scanner inputDevice = new Scanner(System.in);
        System.out.println("please enter a password with an uppercase -->");
        password = inputDevice.nextLine();

        if(password.toUpperCase())
        {
            System.out.println("thank you for your personal info :)");
        }
        if(String.toUpperCase(password))
        {}
        if(isDigit(password))
        {
        }
        if(){

        }
        else{
            System.out.println("plese enter a valid pasword");
            password = inputDevice.nextLine();
        }

    }//close main
}
