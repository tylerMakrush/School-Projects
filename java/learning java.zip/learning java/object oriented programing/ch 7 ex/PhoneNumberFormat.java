import java.util.Scanner;
public class PhoneNumberFormat {
    public static void main(String[] args) {

        String num;
        int count;

        Scanner inputDevice = new Scanner(System.in);
        System.out.println("please enter a valid phone number ");
        num = inputDevice.nextLine();
        count = num.length();

    if(count != 10){
        System.out.println("please enter a valid phone number");
        num = inputDevice.nextLine();
        count = num.length();
    }
    
    if(count == 10){
        StringBuilder phone = new StringBuilder(num);
        phone.insert(0,"(");
        phone.insert(4, ")");
        phone.insert(8, "-");

        System.out.println("this is your phone number " + phone);
    }
    else{
        System.out.println("i dont know what you did but what if you didint ");
    }
        
    }
}
