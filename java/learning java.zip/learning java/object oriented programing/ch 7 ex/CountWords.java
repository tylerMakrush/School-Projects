import java.util.Scanner;
public class CountWords {
    public static void main(String[] args) {
    
        String userIn;
        int num;

        Scanner inputDevice = new Scanner(System.in);
        System.out.println("enter a word and i shall court your letters ");
        
        userIn = inputDevice.nextLine();
        num = userIn.length();
        System.out.println("and the count shall be... " + num);
    }
}
