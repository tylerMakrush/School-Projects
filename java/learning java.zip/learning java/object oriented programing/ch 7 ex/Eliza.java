import java.util.Scanner;
public class Eliza {
   public static void main(String[] args) {
      String user;

      Scanner inputDevice = new Scanner(System.in);

      System.out.println("please tell me your problems");
      user = inputDevice.nextLine();
      do
      {
      if(user.indexOf("my") !=-1){
         System.out.println("tell me more about your ");
         user = inputDevice.nextLine();
      }
      else if(user.indexOf("love")!=-1){
         System.out.println("you seem to have strong feelings about");
         user = inputDevice.nextLine();
      }
      else if(user.indexOf("hate")!=-1){
         System.out.println("you seem to have strong feelings about");
         user = inputDevice.nextLine();
      }
      else if(user.indexOf("sad")!=-1){
         System.out.println("why does it make you sad");
         user = inputDevice.nextLine();
      }
      else if(user.indexOf("whish")!=-1){
         System.out.println("why do you feel like that");
         user = inputDevice.nextLine();
      }
     
     else{
        System.out.println("please go on");
        user = inputDevice.nextLine();
     }
   }while(user.indexOf("stop")!=-1);
   } 
}
