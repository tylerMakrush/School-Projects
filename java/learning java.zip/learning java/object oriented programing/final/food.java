public class food extends math
{
    protected String name;
    protected double calories;
    protected double fat;
    protected double suger;
    protected String n;
    protected double c;


public food(String n, double c){
    this.n = n;
    this.c = c;

}
public food(){
    n = "";
    c = 0;
}
public String getN(){
    return this.n;
}
public void setN(){
    this.n = n;
}
public double getC(){
    return this.c;
}
public void setC(){
    this.c = c;
}
public String toString(){
    
    String message;

    message = "the food you have chosen was " + name + " and it has a total of " + calories + " calories " + " it has a total of " + suger + " as well as  " + fat + " fat";
    return message;
}


}