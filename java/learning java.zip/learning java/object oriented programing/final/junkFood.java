public class junkFood extends food {
    
    
    @Override
    public String toSring()
    {
        
        return "the name of your food is " + name + " the calories are " + calories 
        + " the amount of fat is " + fat + " and it has " + suger + " suger";
    }
   

}
