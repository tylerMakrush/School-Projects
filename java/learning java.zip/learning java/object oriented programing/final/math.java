public class math {
 
    protected int x;
    protected int[] num ;
    protected int count;
    protected int y = 0;

    do{
        num[y] = (int) (Math.random()*20);;
        y++;
    }while(num[y] != 20);
    
    do
    {
    if(num[x] == 5){
        count++;
        x++;
    }
    else
    x++;
    }while(num[x] != 20);


    

    System.out.println("there wherer " + count + " number 5s");
      
}
