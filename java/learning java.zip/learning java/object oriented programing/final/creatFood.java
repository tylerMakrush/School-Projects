public class creatFood extends food
{
    public String words = " hello i am a string and i have a lot of the letter as.";
   
    private static food []somefood = new food[5];
    
    public static void fillSomeFood(){
      somefood[0] = new food();
      somefood[0].setN("cheesy burber");
      somefood[0].setC(50);

      somefood[1] = new food();

      somefood[2] = new food();

      somefood[3] = new food();

      somefood[4] = new food();
    }
    public static void main(String[] args)throws Exception 
    {
        
        
    }   
}