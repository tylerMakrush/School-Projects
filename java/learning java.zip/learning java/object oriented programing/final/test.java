public class test{
    
    private String name;   
    private double score;
}
public stadic(String name, double score){
    
}