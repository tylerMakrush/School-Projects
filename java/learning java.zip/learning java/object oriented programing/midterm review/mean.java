import java.util.Scanner;
public class mean{
    

    public static void main(String[] args) {
        
    String[] rude = {"dumb" , "lame" ,"stinky"};
    String user;

        Scanner inputDevice = new Scanner(System.in);

      System.out.println("i will make you feel big sad are you ready... enter yes to feel bad");

      user = inputDevice.nextLine();

      do

      if(user.indexOf("yes") !=-1){
        System.out.println(message);
      }
      else{
          System.out.println("ok well if you want to cry then i guess if you type in no you can leave");
      }
    
    while(user.indexOf("no") !=-1);

    }
}