public class make extends mean 
{
    protected String one;
    protected String two;
    protected String three;

    public insult(String rude[0], String rude[1], String rude[2])
    {

        String message;

        one = rude[0];
        two = rude[1];
        three = rude[2];

        message = ("you are sooooo " + one + ". yeah you " + two + " and " + three + " yeah are you sad good mic drop");
        
        return message;
        
    }
}
