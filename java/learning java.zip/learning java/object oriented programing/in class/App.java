import java.lang.ProcessBuilder.Redirect.Type;
import java.sql.RowId;
import java.util.Scanner;

public class App{
    public static void main(String[] args) {
        String[] cars = {"BMW","VM","Cheavy","Ford"};
        //int[] myNums = {10, 20, 30, 40};

        //cars[2] = "Honda";
        //System.out.println(cars[2]);
        //System.out.println(cars.length);
    
        //for(int i = 0; i< cars.length; i++){
          //  System.out.println(cars[i]);}
        //for each loop
        //for(Type variable; arrayname)
        //for(String i:cars){
        //    System.out.println(i);}
        
         //int[][] myNums = { {1,2,3,4}, {5,6,7,8} };

    //     int x = myNums[1][2];
    //     System.out.println(x);

    //for(int i = 0; i < myNums.length; ++i){
        // for(int j = 0; j <myNums[i].length; ++j){
        //     System.out.println(myNums[i][j]);
        // }
    //}
    int[] scores = new int[10];
    int score = 0;
    int count = 0;
    int total = 0;
    final int QUIT = 999;
    final int MAX  = 10;

    Scanner input = new Scanner(System.in);

    System.out.println("enter quis score or " + QUIT + " to quit>>");
    score = input.nextInt();

    while(score !=QUIT){
        scores[count] = score;
        total += scores[count];
        ++count;
        if(count == MAX){
            score = QUIT;
        }
        else{
            System.out.println("enter next quiz score or " + QUIT + " to quit>>");
            score = input.nextInt();
        }
    }
    System.out.println("\nthe scores entere were ");
    for(int x =0; x < count; ++x){
        if(count != 0){
        System.out.println(scores[x] + " \n the avrage is " + (total * 1.0/count));
        }
        else{
            System.out.println("no scores were entered");
            }
    }
    }
}