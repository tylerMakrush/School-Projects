public class TestBankAccount
{
   public static void main(String[] args)
   {
      BankAccount myAccount = new BankAccount(123, 4567.89);
      System.out.println(myAccount.toString());
   }
}
