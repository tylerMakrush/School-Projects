public class DisplayDog
{
   public static void main(String[] args)
   {
      Dog myDog = new Dog();
      String dogString = myDog.toString();
      System.out.println(dogString);
   }
}
