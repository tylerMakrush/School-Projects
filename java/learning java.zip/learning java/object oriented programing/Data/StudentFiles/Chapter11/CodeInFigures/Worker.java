public interface Worker
{
   public void work();
}