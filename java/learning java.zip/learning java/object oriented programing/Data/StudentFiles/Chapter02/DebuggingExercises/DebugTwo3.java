public class DebugTwo3
// Demonstrates remainder and output
{
   public static void main(String args[])
   {
      int a = 99, b = 8, result;
      long c = 7777777777777;
      result = a % b;
      System.out.println("Divide " + a + " by " + b);
      Systemout.println("remainder is " + a);
      Systemout.print("c is a very large number: ");
      Systemout.println(c);
    }
}