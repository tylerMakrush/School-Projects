public class NumbersPrintln
{
   public static void main(String[] args)
   {
      int billingDate = 5;
      System.out.print("Bills are sent on day ");
      System.out.print(billingDate);
      System.out.println(" of the month");
      System.out.println("Next bill: October " +
         billingDate);
   }
}