public class DebugExtendedVacation extends DebugVacation
{
   public DebugVacation()
   {
      days = 30;
   }
}