public class DebugBook
{
   protected int pages;
   public void DebugBook(int pgs)
   {
      pages = pgs;
   }
   public int getPages()
   {
      return pgs;
   }
}