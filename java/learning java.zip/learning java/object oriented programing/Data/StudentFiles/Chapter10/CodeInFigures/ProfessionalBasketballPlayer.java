public class ProfessionalBasketballPlayer extends BasketballPlayer
{
   double salary;
   @Override
   public void displayMessage()
   {
      System.out.println("I have nothing to say");
   }
}  
