public class TestProPlayer
{
   public static void main(String[] args)
   {
      ProfessionalBaseballPlayer aYankee =
         new ProfessionalBaseballPlayer();
      aYankee.showOrigins();
   }
}
