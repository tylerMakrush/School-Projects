import java.util.Scanner;
public class DistanceFromAvrerge {
    public static void main(String[] args) {

        
        double[] usernum = {1,2,3};

        double user;

        double av;

        Scanner inputDevice = new Scanner(System.in);

        System.out.println("enter the values");
        user = inputDevice.nextDouble();
        
        usernum[0] = user;
        
        System.out.println("please enter a nother number");
        
        user = inputDevice.nextDouble();
        usernum[1] = user;

        System.out.println("please enter a nother number");
        user = inputDevice.nextDouble();
        
        usernum[2] = user;

        av = usernum[0] + usernum[1] + usernum[2];
        
        do{
            
        if(user <= 20 ){
            System.out.println("number one is " + (usernum[0] - av) + " away from the avrage");
            user = inputDevice.nextDouble();
        }
        else{
            System.out.println("error in the matrix");
            user = inputDevice.nextDouble();
        }

    }while(user != 9999);

    System.out.println("thank you for your time");
    }
}
