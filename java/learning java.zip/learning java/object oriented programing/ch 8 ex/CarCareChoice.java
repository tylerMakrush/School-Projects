import java.util.Scanner;
public class CarCareChoice {
    public static void main(String[] args) {
        int[] care = {1,2,3,4};
        String user;
        
        Scanner inputDevice = new Scanner(System.in);
        System.out.println("please enter the servive you would like us to provide");
        user = inputDevice.nextLine();

        if(user.indexOf("str") !=1){

        }
        else if(user.indexOf("str") !=1){

        }
        else if(user.indexOf("str") !=1){

        }
        else if(user.indexOf("str") !=1){

        }
        else{
            System.out.println("i am sorry,but we do not provide that serice");
        }
    }
}
