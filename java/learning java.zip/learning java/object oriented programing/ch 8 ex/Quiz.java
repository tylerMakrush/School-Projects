import java.util.Scanner;
public class Quiz {
    public static void main(String[] args) {

        String user;

        String[] q1 = {"A...becouse of a glitch with a pig ","B...i donno","C...someone stuffed TNT in a bunch of moss","a","b","c"};
        String[] q2 = {"anchent warfair","swiss army knife",""};
        String[] q3 = {};
        String[] q4 = {};
        String[] q5 = {};
        
        System.out.println("please enter the correct responce to the folowing questions about minecraft");
        Scanner inputDevice = new Scanner(System.in);

      
        do{
            System.out.println("how did the creeper come into being");
            System.out.println(q1[0]);
            System.out.println(q1[1]);
            System.out.println(q1[2]);
    
            user = inputDevice.nextLine();

        if(user.indexOf("A") !=-1){
            System.out.println("good job that is correct");
        }
        else if(user.indexOf("B") !=-1){
            System.out.println("sorry the correct responce was ...");
            System.out.println(q1[0]);
            user = inputDevice.nextLine();
        }
        else if(user.indexOf("C") !=-1){
            System.out.println("sorry the correct responce was ...");
            System.out.println(q1[0]);
            user = inputDevice.nextLine();
        }
        else{
            System.out.println("can you please take this more sereousl and type a valid responce please");
            user = inputDevice.nextLine();
        }
    }while(user.indexOf("A...becouse of a glitch with a pig") !=-1);


    do{
            System.out.println("what is my favorit mod??");
            System.out.println(q2[0]);
            System.out.println(q2[1]);
            System.out.println(q2[2]);
            if(user.indexOf("A") !=-1){
                System.out.println("yep all the mods are right ");
            }
            else if(user.indexOf("B") !=-1){

            }
            else if(user.indexOf("C") !=-1){

            }
            else{
                System.out.println("please enter a valit responce");
            }
    }while(user.indexOf("B") !=-1);



            System.out.println("x");
            System.out.println(q3[0]);
            System.out.println(q3[1]);
            System.out.println(q3[2]);

            System.out.println("x");
            System.out.println(q4[0]);
            System.out.println(q4[1]);
            System.out.println(q4[2]);

            System.out.println("x");
            System.out.println(q5[0]);
            System.out.println(q5[1]);
            System.out.println(q5[2]);



    }// closes main
    
}
