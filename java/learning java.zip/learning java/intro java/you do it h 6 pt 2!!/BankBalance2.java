import java.util.Scanner;
public class BankBalance2{
    public static void main(String[] args) {
    double balance;
    int response;
    int year = 1;
    final double INT_RATE = 0.03;

    Scanner keyboard = new Scanner(System.in);
    System.out.println("enter initl bank balance >>>");
    balance = keyboard.nextDouble();
    keyboard.nextLine();
    
    do
    {
        balance = balance + balance *INT_RATE;
        System.out.println("after year " + year + " at " + INT_RATE + " intrest rate, balance is $" + balance);
        year = year + 1;
        System.out.println("do you want to see the balace " + " at the end of an other year");
        System.out.println("enter 1 for yes");
        System.out.println("or any other number for no >>>>>>>>>>>>>>>>>");
        response = keyboard.nextInt();
    }
    while(response == 1);

    }
}