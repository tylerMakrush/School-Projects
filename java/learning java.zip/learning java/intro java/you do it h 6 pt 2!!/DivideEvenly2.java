public class DivideEvenly2 {
    public static void main(String[] args) {
    final int LIMIT = 100;
    int var;
    int numer;
    System.out.println(LIMIT+" is evenly divisible by ");    
   for(numer = 1; numer <= LIMIT; ++numer)
    {
       System.out.println(numer + " is evenly divisible by ");
        for (var = 1; var <= numer; ++var)
        if(numer % var ==0)
        System.out.println(var + " ");
        System.out.println();
    }
 
    }   
}
