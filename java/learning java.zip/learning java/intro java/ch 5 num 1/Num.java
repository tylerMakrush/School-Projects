import java.util.Scanner;
public class Num{

    public static void main(String[] args) 
    {
        int num;
        Scanner keyboard = new Scanner(System.in);

        System.out.println("enter a number and i will tell you if it is even or odd");

        num = keyboard.nextInt();
        if (num / 2)
        System.out.println("the number that you entered is even");

        else
        System.out.println("the number that you entered is odd");
    }
}
