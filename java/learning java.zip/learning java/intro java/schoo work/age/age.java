import java.util.Scanner;
public class age {
public static void main(String[] args) {

        String name;
        int age;
        int young;
        int old;
   
        System.out.println( "what is your name");
        Scanner input = new Scanner(System.in);
        System.out.println("how old are you???");
        age = input.nextInt();
        young = ( age - 5 );
        System.out.println("did you know that 5 years ago you were" + young + (" you little kid hah") );
        old = (age + 5);
        System.out.println("and 5 years from now you will be"+ old +( "wow your gonna be sooooo old "));
    }
}