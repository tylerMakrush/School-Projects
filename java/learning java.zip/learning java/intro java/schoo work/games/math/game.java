import java.util.Scanner;
public class game
{
    public static void main(String[] args)
    {
        int number ;
        int difference;
        int random;
        Scanner input = new Scanner(System.in);
        System.out.print("plese enter a number 1 and 10");
        number = input.nextInt();
        random = (1 + (int)(Math.random()* 10));
        System.out.print("the number is " + random);
        difference = number - random;
        System.out.print("the diffrence" + difference);
        
    }
}