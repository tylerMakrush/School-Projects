import javax.swing.JOptionPane;
import java.util.Scanner;

public class mindlab {
    public static void main(String[] args) {
        String nounA, nounB;
        String adjetive, verb;
        nounA = JOptionPane.showInputDialog(null, "Please enter a noun", "The Noun", JOptionPane.QUESTION_MESSAGE);

        nounB = JOptionPane.showInputDialog(null, "please enter a nother noun");

        adjetive = JOptionPane.showInputDialog(null, "please enter an adjetive");

        verb = JOptionPane.showInputDialog(null, "please enter a past tense verb");

        System.out.println(" Mary had a little " + nounA);
        System.out.println("its " + nounB + " was  " + verb + " as snow ");
        System.out.println(" the " + adjetive);

        System.out.println();
    }
}
