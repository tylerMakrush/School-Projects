import java.util.Scanner;

import javax.swing.JOptionPane;
public class MoreUser
{
    public static void main(String[] args)

    {
        Scanner inputDevice = new Scanner (System.in);
        String Fname, Lname;
        String grades;
        String login;
       double  GPA;
    System.out.print( "please enter your first name" );
        Fname = inputDevice.nextLine ();
    Scanner imputDevice = new Scanner(System.in);
    System.out.print( "please enter your last name" );
    Lname = inputDevice.nextLine ();
    System.out.print("please enter your grade ");
    grades = inputDevice.nextLine ();
    System.out.print ("please provide your login");
        login = inputDevice.nextLine ();
    System.out.print ("please provide your GPA");
        GPA = inputDevice.nextInt ();
        imputDevice.close();
    }
}
