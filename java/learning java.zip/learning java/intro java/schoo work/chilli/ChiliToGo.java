import java.util.Scanner;
public class ChiliToGo {
 public static void main(String[]args){
         Scanner inputDevice = new Scanner(System.in);
        final int AdultPrice = 7;
        final int ChildPrice = 4;

        int adultMeal;
        int childrenMeal;
        int adultSales;
        int childrenSales;
        int total;
        int AdultAmount;
        int ChildAmount;

                System.out.println("please enter the adult sales");
                adultMeal = inputDevice.nextInt();
                System.out.println( "please enter the childrens sales");
                childrenMeal = inputDevice.nextInt();
                 total = (adultMeal * AdultPrice) + (childrenMeal * ChildPrice);
                System.out.println("you have made" + total);


        }
}