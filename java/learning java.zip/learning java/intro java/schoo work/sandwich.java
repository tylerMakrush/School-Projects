import java.util.Scanner;
public class sandwich {
    String meat;
    String bread;
    double price = 0;
    
    public static main()
    {
      

        Scanner inport = new Scanner(System.in);

        System.out.println("what type of meat witll the costomer be buying");
        meat = inport.nextLine();

        System.out.println("what type of bread will the costomer be buying");
        bread = inport.nextLine();
        
        price = meatPrice(meat) + breadPrice(bread);
        

        System.out.println("he costomers total is " + price + ("$"));
    }
    
    public double meatPrice(String meat) {
        if 
        (
            meat.equals("tuna") 

        )
        {
            return ((double) 4.99);
        }
        else if 
        (
            meat.equals("ham")
        )
        {
            return ((double) 3.99);
        }  
        return ((double) 0);     
    }
    public double breadPrice(String bread)
    {
        if 
        (
            bread.equals("wheat")
        )
        {
            return ((double) 99.00);      
        }
        else if
        (
            bread.equals("white")
        )
        {
            return ((double) 2.00);
        }
        return ((double) 0);
    }
}