import javax.swing.JOptionPane;
public class game2{

public static void main(String[] args)
    {System.out.println("pick a number between 1 and 10");

    }

    {


    JOptionPane .showConfirmDialog("the number is" +(1 + (int)(Math.random()* 10)));

    }

}