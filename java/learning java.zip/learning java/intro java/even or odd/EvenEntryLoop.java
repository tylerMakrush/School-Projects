import java.util.Scanner;
public class EvenEntryLoop{
    public static void main(String[] args) {
    int usernum;

    Scanner input = new Scanner(System.in);
    System.out.print("please put an even number :)  >>>");
    usernum = input.nextInt();
    

    do
{
    if ( usernum % 2 == 0 )
    {
        System.out.println("congrats that number is in fact an even number :) if you would like to end this then enter number 999");
        usernum = input.nextInt();
    }
    else if(usernum == 999)
    {
        System.out.println("thank you");
    }

        else 
        {
        System.out.println("error  please provide an even number :(");
        usernum = input.nextInt();
        }
}   while(usernum != 999);

    System.out.println("you are free of this cycle :)");
    }

}