import java.util.Scanner;

public class AssignVolunteer
{
    public static void main(String[] args)
    {
        int donationType;
        String volunteer;
        final int CLOTHONG_CODE=1;
        final int OTHER_CODE=2;
        final String CLOTHING_PRICER ="Regaina";
        final String OTHER_PRICER="marco";

        Scanner input = new Scanner(System.in);

        System.out.println("what type of donation is this????");
        System.out.println("Enter " + CLOTHONG_CODE + "for clothing, " + OTHER_CODE + " for anything else..........");
        donationType = input.nextInt();
        if(donationType==CLOTHONG_CODE)
           volunteer = CLOTHING_PRICER;
        else volunteer = OTHER_PRICER;

        System.out.println("you entered " + donationType);
        System.out.println("the volunteer who will price this item is " + volunteer);

    }

}