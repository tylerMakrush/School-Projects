public class First{

public static void main (String []args){
System.out.println("X                                  x");
System.out.println("x                                  x");
System.out.println("x                                  x");
System.out.println("xxxxx      xxxxxxxxxx        xxxxxxxx");
System.out.println("x   x      x        x        x      x");
System.out.println("x   x      x        x        x      x");
}


}