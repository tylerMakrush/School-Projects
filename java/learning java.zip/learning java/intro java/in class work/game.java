import javax.swing.JOptionPane;
public class game
{
    public static void main(String[] args)
    {
        JOptionPane.showMessageDialog(null,"think of a number between one and ten");
        JOptionPane.showMessageDialog(null,"the number is " + (1 + (int)(Math.random()* 10)));
        
            Scanner imputDevice = new Scanner(System.in);
            
        
    }
}

