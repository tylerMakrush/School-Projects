public class IntegerdemoInteractive {
    

    import java.util.Scanner;    
}