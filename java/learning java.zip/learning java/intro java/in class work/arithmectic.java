import javax.swing.JOptionPane;
public class arithmetic{

    
}