import javax.swing.JOptionPane;
public class CarlysMotto {
    public static void main(String[] args){
    JOptionPane.showMessageDialog(null,"carlys makes the food that makes it a party");
    }

}
