public class percentage
 {
    public static void main(String[] args)
    {
         
        double numone = 2;
        double numtwo = 4;

        System.out.print("the percentage of the fiirst number you put in to the other is " + perc(numone,numtwo)); 
         
     }
     public static double perc(double numone, Double numtwo)
     {
       double percent;
       percent = ((numone / numtwo) * 100);
       return percent;
     }
}

