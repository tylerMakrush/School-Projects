import java.util.Scanner;

public class percentage2 {
  
    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);

        double numone;
        double numtwo;

        System.out.println("please provide the number of points you got");
        numone = input.nextInt();
        System.out.println("please provide the number of avalible points");
        numtwo = input.nextInt();
        
        System.out.print("your percentage was "  + perc(numone,numtwo)); 
         
     }
     public static double perc(double numone, Double numtwo)
     {
       double percent;
       percent = ((numone / numtwo) * 100);
       return percent;
     }  
}
