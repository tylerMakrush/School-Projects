public class ShowStudent {
    public static void main(String[] args){
        Student s1 = new Student();
        s1.setstudentId(99999);
        s1.setcredits(10);
        s1.setpointsEarned(9);

        System.out.println("your student id is " + s1.getstudentId());
        System.out.println("the student credits avalible " + s1.getcredits());
        System.out.println("the students points earned " + s1.getpointsEarned());
        s1.calcGpa();
        System.out.println("your student gpa is " + s1.getgpa());
    }
}
