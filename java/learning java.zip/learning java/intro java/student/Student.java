public class Student
{
    private int studentId;
    private double credits;
    private double pointsEarned;
    private double gpa;

    public void setstudentId(int s){
        studentId = s;
    }

    public int getstudentId(){
        return studentId;
    }

    public void setcredits(double c){
        credits = c;
    }

    public double getcredits(){
        return credits;
    }
    public void setpointsEarned(double p){
        pointsEarned = p;
    }

    public double getpointsEarned(){
        return pointsEarned;
    }

    public double getgpa(){
        return gpa;
    }
 
    
    public void calcGpa(){

        gpa = pointsEarned / credits;
    }
}