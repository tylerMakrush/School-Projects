      public class Sandwitch 
    {
        String mainIngred;
        String bread;
        double price;

        public String getmainIngred()
        {
            return mainIngred;
        }
        public String getbread()
        {
          return bread;
        }
         public double getPrice()
        {
             return price;
        }
        
        public void setmainIngred(String tuna) 
        {
            mainIngred = tuna;
        }
            public void setbread(String wheat)
        {      
            bread = wheat;
        }
        public void setPrice(double pr)
        {
            price = pr;
        }
    }