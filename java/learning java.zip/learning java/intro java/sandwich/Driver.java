public class Driver {
    public static void main(String[] args)
    {
    Sandwitch s1 =  new Sandwitch();

    s1.setbread("wheat");
    s1.setmainIngred("tuna");
    s1.setPrice(4.99);
    System.out.println("the main ingredieant is " + s1.getmainIngred());
    System.out.println("the bread is " + s1.getbread());
    System.out.println("the price is " + s1.getPrice());
    }
}