import java.util.Scanner;
public class CondoSales
{
    public static void main(String[] args) {

        int view;
        int garage;
        double total = 0;

        Scanner keyboard = new Scanner(System.in);
        System.out.println("if you do not wish to purches plese enter 0");
        System.out.println("please type a 1 if you want a park view");
        System.out.println("type 2 for a golf view");
        System.out.println("enter 3 for a lake view");
        view = keyboard.nextInt();
        System.out.println("if you would like a garage please enter 4...");
        garage = keyboard.nextInt();

    
        if (view == 1)
            total = 15000;
        else;
        if( view == 2)
        total = 170000;
        else;
        if(view == 3)
        total = 21000;
    
        if (garage == 4)
        total += 5000;

        else {total += 0;
         System.out.println("you chose not to add a garage"); }
           
        System.out.println("thank you. your total will be " + total);
    }
}