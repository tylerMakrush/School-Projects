
public class card
{

    final int CARDS_IN_SUIT = 13;
    int cNum;

    cNum = ((int)(Math.random() * 100 % CARDS_IN_SUIT + 1));

    public void setcard(){
        
    }


}