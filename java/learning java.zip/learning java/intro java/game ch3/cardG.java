public class cardG {
    public static void main(String[] args) {
        card s1 = new card();
        cNum = ((int)(Math.random() * 100 % CARDS_IN_SUIT + 1));
        
    }
}