public class DemoIncrement2{
    public static void main(String[] args) {
    int v = 4;
    int plusPlusV = ++v;

    v = 4;
    int vplusPlus = v++;
    
    System.out.println("v is " + v);
    System.out.println("++v is " + plusPlusV);
    System.out.println("v++ is " + vplusPlus);

    int w  = 17, x=17, y = 18;
    boolean comparel1 = (++w == y);
    boolean comparel2 = (x++ == y);

    System.out.println("first compare is " + comparel1);
    System.out.println("second compare is " + comparel2);
    }
}