import java.util.Scanner;

public class gameran 
{
    public static void main(String[] args)
    {
        double tNumber;
        int userNumber;
        Scanner input = new Scanner(System.in);

        System.out.println("can you guess the number that i am thinking ...");
        System.out.println("i will give you a hint its between 1 and 10 now go");
        userNumber = input.nextInt();
         
        tNumber = 1 + (int)(Math.random() * 10);

        if(userNumber == tNumber) {
        
        System.out.println("congrats you are one good guessers");
        System.out.println("game over");
        }
         else if (userNumber>=tNumber)

            System.out.println("your gusee was too high");

        else 

            System.out.println("your guess was to low");
        

        System.out.println("the number was..." + tNumber);
        
        
        
        
    }
}