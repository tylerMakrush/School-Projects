import java.util.Scanner;
public class inbetween
{
    public static void main(String[] args) 
    {
    int userNum;
    int userNum2;
    int num = 0;

    Scanner keyboard = new Scanner(System.in);
    System.out.println("please enter a number ---->");
    userNum = keyboard.nextInt();
    System.out.println("please enter another number --->");
    userNum2 = keyboard.nextInt();
if(userNum - userNum2 == 1 || userNum -userNum2 == -1 || userNum - userNum2 ==0)
{
    System.out.println("error glitch in the matrix try again");
    userNum = keyboard.nextInt();
    userNum2 = keyboard.nextInt();
}
else

do
{

    if(userNum - userNum2 >= 2)
    {
        num++;
        
        userNum = userNum - 1;
        
    }
    else if(userNum - userNum2 <= 2)
    {
        num++;

       userNum2 = userNum2 - 1;
    }
    else
    {
        System.out.println("dont make me angry you wouldint like me when i am angry   >:-( ");
    }
}while(userNum - userNum2 != 1 || userNum -userNum2 != -1 || userNum - userNum2 != 0);


    System.out.println("there are " + num + " intigers between your two numbers");
     
    }
}