public class quart
{
    public static final int quartInGallon = 4;
    public static int quartsRequired = 18;
    public static int neededGallons;
    public static int neededQuarts;

    public static void main(String[] args) {
     neededGallons = (quartsRequired / quartInGallon);
     neededQuarts = (quartsRequired % quartInGallon);
        System.out.print("A job that needs " + neededGallons + " quarts requires " + 4 + " gallons plus " + neededQuarts + " quarts.");
    }
}