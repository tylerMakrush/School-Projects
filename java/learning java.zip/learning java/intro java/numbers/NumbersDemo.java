public class NumbersDemo{
        public static void main(String[]args){
            int number1=2;
            int number2=4;

            displayTwiceTheNumber(number1);
            displayNumberPlusFive(number1);
            displayNumberSquared(number1);
        
            displayTwiceTheNumber(number2);
            displayNumberPlusFive(number2);
            displayNumberSquared(number2);
        }
        public static void displayTwiceTheNumber(int num) {
            System.out.println("the number times 2 "+ (num * 2));
        }

        public static void displayNumberPlusFive(int num){
            System.out.println("the number plus 5"+ (num + 5));
        }
        public static void displayNumberSquared(int num){
            System.out.println("the number squared is" + (num * num));
        }


}