import java.util.Scanner;

public class NumbersDemo2 {
public static void main(String[]args){
    
    int number1;
    int number2;

    Scanner input = new Scanner(System.in);
        System.out.print("please enter 2 numbers!!!!!!!!!");
        number1 = input.nextInt();
        number2 = input.nextInt();

        input.close();

    displayTwiceTheNumber(number1);
    displayNumberPlusFive(number1);
    displayNumberSquared(number1);

    displayTwiceTheNumber(number2);
    displayNumberPlusFive(number2);
    displayNumberSquared(number2);
}
    public static void displayTwiceTheNumber(int num) {
        System.out.println("the number times 2 "+ (num * 2));
}

    public static void displayNumberPlusFive(int num){
        System.out.println("the number plus 5"+ (num + 5));
}
    public static void displayNumberSquared(int num){
        System.out.println("the number squared is" + (num * num));
}


}