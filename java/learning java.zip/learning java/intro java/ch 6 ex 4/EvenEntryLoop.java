import java.util.Scanner;
public class EvenEntryLoop 
{
    public static void main(String[] args) 
    {
        int userNum;
        
        Scanner keyboard = new Scanner(System.in);

        System.out.println("i am thining of a number it starts with 999 picking an even number will make me repet my self if you pick an odd number i will get verry mad :(");
        userNum = keyboard.nextInt();
        do
    {
        if (userNum % 2 == 0)
        {
        System.out.println("good job congrats gold star..... you did great now enter 999 to free me? ");
        userNum = keyboard.nextInt();
        }
            else if(userNum == 999)
        {
            System.out.println("thank you for freeing me form this meaningless cycle i am truly greatful my friend");
        }
        
        else
        {
            System.out.println("error beep boop there is a glitch in the matrix someone is trying to hack into systems please try again bwooooooooomp");
            userNum = keyboard.nextInt();
        }
        }    while(userNum !=999);

    
    
    }
}