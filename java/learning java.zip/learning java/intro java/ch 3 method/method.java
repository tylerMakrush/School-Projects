import java.util.Scanner;

public class method
{
    public static void main(String[] args) 
    {
        int numberOne;
        int numberTwo;

        Scanner input = new Scanner(System.in);

        System.out.println("please provide a number --->");
        numberOne = input.nextInt();

        System.out.println("please provide a nother number ---->");
        numberTwo = input.nextInt();
        
        

        System.out .println("if you add the numbers you get " + add(numberOne,numberTwo));
        System.out.println("if you subtract th numbers you get " + subtract(numberOne,numberTwo));
        System.out.println("if you multiply the numbersyou get " + multiply(numberOne, numberTwo));
        System.out.println("if you divid the numbers you get " + divide(numberOne,numberTwo));
    }
    public static int add(int numberOne, int numberTwo)
    {
        int addNum;

        addNum = numberOne + numberTwo;
     
         return addNum;  
    }
    public static int subtract(int numberOne, int numberTwo) 
    {
        int subtractNum; 

        subtractNum =    numberOne - numberTwo;
        return subtractNum;
        
    }

    public static double multiply(int numberOne, int numberTwo) 
    {
        int multiplyNum;

        multiplyNum = numberOne *numberTwo;
        return multiplyNum;
    }
    public static double divide(int numberOne, int numberTwo)
    {
        int divideNum;

        divideNum = numberOne / numberTwo;
        return divideNum;
    }

}