import java.util.Scanner;
public class EnterSmallValue {
    public static void main(String[] args) {
        int userEntery;
        final int LIMIT = 3;
        Scanner input = new Scanner(System.in);
        System.out.print("please enter an interger no highter than " + LIMIT);
        userEntery = input.nextInt();
        while (userEntery > LIMIT)
        {
            System.out.println("the number you entered was too hight");
            System.out.println("please enter an intager o higher then " + LIMIT);
            userEntery = input.nextInt();
        }
        System.out.println("you correctly entered " + userEntery);
    }
}
