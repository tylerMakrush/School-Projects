import java.util.Scanner;
public class BankBalance 
{
    public static void main(String[] args) {
        double balance;
        int response;
        int year =1 ;
        final double INT_RATE = 0.03;

        Scanner keyboard = new Scanner(System.in);
        System.out.print("enter inital balence > ");
        balance = keyboard.nextDouble();
        System.out.println("do you want to see next years balance?????");
        System.out.print("enter 1 for yes");
        System.out.print("or any other number for no");
        response = keyboard.nextInt();
        while (response == 1)
        {
            balance = balance + balance * INT_RATE;
            System.out.print("after year " + year + " at " + INT_RATE + 
            "intrest rate, balance is $" + balance);
            year = year + 1;
            System.out.println("do you want to see the balance " + "at theh end of another year?");
            System.out.print("enter 1 for yes");
            System.out.print("or any other numberer for no >>>>>>>>");
           response = keyboard.nextInt();

        }
    }
}