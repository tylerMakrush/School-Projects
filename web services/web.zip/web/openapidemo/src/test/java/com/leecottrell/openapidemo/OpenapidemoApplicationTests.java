package com.leecottrell.openapidemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OpenapidemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
