package com.leecottrell;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class Secure {//this is where i made my edits
    public static void main(String[] args){
        
        checkAUser("tdm15@students.ptcollege.edu","AQAAAAEAACcQAAAAEOVGWTuoUHDL8Jiqk5SSSUupJMJpX524wyCukARSVno9mYhiAuYeRTSqP82qYrKg1g==" );
        
    }
    public static void checkAUser(String username,String Pass){
        String connectionURL = "Server=tcp:guidatabase.database.windows.net,1433;Initial Catalog=schoolDatabase;Persist Security Info=False;User ID=tyler;Password=Halowars42;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";

        try(Connection con = DriverManager.getConnection(connectionURL);
        Statement stmt = con.createStatement();){
            String SQL = "select UserName ,PasswordHash ,RoleId from dbo.AspNetUsers users join dbo.AspNetUserRoles userrol on users.id =  userrol.UserId ";
            ResultSet rs = stmt.executeQuery(SQL);

            while (rs.next()) {
                if(username == rs.getString("UserName")){
                    if(Pass == rs.getString("PasswordHash") ){
                        int rsid = Integer.valueOf( rs.getString("RoleId"));
                        switch (rsid) {
                            case 1:
                                
                                
                                break;
                        
                            case 2:
                                break;
                        }
                    }
                }
            }
        }
        catch(SQLException e){
            e.printStackTrace();
        }
        
    }   
}
