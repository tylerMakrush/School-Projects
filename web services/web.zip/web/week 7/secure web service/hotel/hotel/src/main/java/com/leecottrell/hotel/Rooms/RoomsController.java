package com.leecottrell.hotel.Rooms;

import java.nio.charset.Charset;
import java.util.*;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.apache.tomcat.util.codec.binary.Base64;
@RestController
public class RoomsController {
    static Map<Integer, Rooms> reservations = new HashMap<Integer, Rooms>();

    public RoomsController() {
        // setup you need for the controller
        reservations.put(515, new Rooms(515, "Cottrell"));
        reservations.put(603, new Rooms(603, "Schurter"));
        reservations.put(402, new Rooms(402, "Eltringham"));
    }

    // modify to accept int parameter or no parameter
    @RequestMapping(value = "/rooms", method = RequestMethod.GET)

    public ResponseEntity<List<Rooms>> getReservations(
            @RequestParam(value = "roomNum", defaultValue = "0") int roomNum,String auth) {
        // Collection<Rooms> results = reservations.values();
        // List<Rooms> response = new ArrayList<Rooms>(results);
        List<Rooms> response = new ArrayList<Rooms>();
        if(validatePassword(auth)){
        if (roomNum < 0 || roomNum > 616) {
            response.add(new Rooms(roomNum, "Room numbers between 0 and 616"));
            return new ResponseEntity<List<Rooms>>(response, HttpStatus.NOT_ACCEPTABLE);
        }
        switch (roomNum) {
            case 0:
                // no parameter passed in, then send entire reservation
                response = new ArrayList<Rooms>(reservations.values());
                break;
            default:
                Rooms found = reservations.get(roomNum);
                if (found == null) {
                    response.add(new Rooms(roomNum, "Room is empty, ready to reserve!"));
                    return new ResponseEntity<List<Rooms>>(response, HttpStatus.NOT_FOUND);
                } else {
                    // passed ina room number
                    response.add(found);
                }
                break;
        }}
        
            response.add(new Rooms(roomNum, "not allowed axes >:("));
        return new ResponseEntity<List<Rooms>>(response, HttpStatus.NETWORK_AUTHENTICATION_REQUIRED);
        
    }

    // POST will add a value to the map
    // POST will accept a JSON document to add
    // POST will check to see if room is legit and available
    @RequestMapping(value = "/rooms", method = RequestMethod.POST)
    public ResponseEntity<Rooms> postReservations(@RequestBody String newRes,String auth) {
        ObjectMapper mapper = new ObjectMapper();
        Rooms response = new Rooms(0, "Error in reservation, not added");
        try {
            response = mapper.readValue(newRes, Rooms.class);
            if (reservations.get(response.getRoomNum()) == null) {
                // room not reserved
                reservations.put(response.getRoomNum(), response);
            } else {
                response.setGuest("Room is already reserved");
                return new ResponseEntity<Rooms>(response, HttpStatus.NOT_ACCEPTABLE);
            }

        } catch (JsonProcessingException jme) {
            // not handled yet
            response.setGuest(jme.getMessage().toString());
            return new ResponseEntity<Rooms>(response, HttpStatus.BAD_REQUEST);
        }
        return new ResponseEntity<Rooms>(response, HttpStatus.OK);
    }

    @RequestMapping(value = "/rooms", method = RequestMethod.PUT)
    public ResponseEntity<Rooms> putReservations(
            @RequestParam(value = "roomNum") int roomNum,
            @RequestParam(value = "addon") String addon,
            String auth) {
                if(validatePassword(auth)){
        Rooms response = new Rooms(0, "empty");

        if (reservations.get(roomNum) == null) {
            // room is not reserved
            response.setGuest("Room is not reserved, reserve before addons");
            response.setRoomNum(roomNum);

            return new ResponseEntity<Rooms>(response, HttpStatus.NOT_FOUND);
        }

        String origGuest = reservations.get(roomNum).getGuest();
        reservations.get(roomNum).setGuest(origGuest + " " + addon);

        response = reservations.get(roomNum);

        return new ResponseEntity<Rooms>(response, HttpStatus.OK);
            }
        Rooms response = new Rooms(0, "not allowed axex >:(");
        
        return new ResponseEntity<Rooms>(response, HttpStatus.NETWORK_AUTHENTICATION_REQUIRED);
    }

    @RequestMapping(value = "/rooms", method = RequestMethod.DELETE)

    public ResponseEntity<Rooms> deleteReservations(@RequestParam(value="roomNum") int roomNum,String auth) {
        if(validatePassword(auth))
    {
        Rooms response = new Rooms(0, "empty");
        
        if (reservations.get(roomNum) == null) {
            // room is not reserved
            response.setGuest("Room is not reserved, cannot delete");
            response.setRoomNum(roomNum);
            return new ResponseEntity<Rooms>(response, HttpStatus.NOT_FOUND);
        }
        response.setGuest("deleted");
        response.setRoomNum(roomNum);
        reservations.remove(roomNum);
        return new ResponseEntity<Rooms>(response, HttpStatus.OK);
    }
        Rooms response = new Rooms(0, "not allowed axex >:(");
        
        return new ResponseEntity<Rooms>(response, HttpStatus.NETWORK_AUTHENTICATION_REQUIRED);
    }
    private String userName;
	private String password;
	private boolean validatePassword(String auth){
		boolean valid = false;
		String userPass = auth.substring(6);
		byte[] decryptArray = Base64.decodeBase64(userPass);
		String decryptString  = new String(decryptArray);
		int colon = decryptString.indexOf(":");
		userName = decryptString.substring(0, colon);
		password = decryptString.substring(0,colon);
		if(userName.equalsIgnoreCase("Tyler")&&password.equals("dc647eb65e6711e155375218212b3964")||
        userName.equalsIgnoreCase("lee")&&password.equals("9c2f924fb2f7004e7979ab2027ca1d65")||
        userName.equalsIgnoreCase("bill")&&password.equals("98eb470b2b60482e259d28648895d9e1")||
        userName.equalsIgnoreCase("bob")&&password.equals("3b98ce28e361cc14bdbaf61eba2a864e")||
        userName.equalsIgnoreCase("ross")&&password.equals("7b1eb511ca387084203220107a67bc53")
        ){
			valid = true;
		}
		else {
			valid = false;
		}
		

		return valid;
	}
    public String buildAuth(String username, String password){
        String authHeader = "";
       String temp = username + ":" + password;
       byte[] encoded = Base64.encodeBase64(temp.getBytes(Charset.forName("US-ASCII")),false);
       authHeader = "Basic " + encoded;
       return authHeader;
   }
}
