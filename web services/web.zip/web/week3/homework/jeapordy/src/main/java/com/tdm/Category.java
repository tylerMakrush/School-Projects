package com.tdm;

public class Category {

private Integer id;
private String title;
private String created_at;
private String updated_at;
private Integer clues_count;

/**
* No args constructor for use in serialization
*
*/
public Category() {
}

/**
*
* @param clues_count
* @param updated_at
* @param created_at
* @param id
* @param title
*/
public Category(Integer id, String title, String created_at, String updated_at, Integer clues_count) {
super();
this.id = id;
this.title = title;
this.created_at = created_at;
this.updated_at = updated_at;
this.clues_count = clues_count;
}

public Integer getId() {
return id;
}

public void setId(Integer id) {
this.id = id;
}

public Category withId(Integer id) {
this.id = id;
return this;
}

public String getTitle() {
return title;
}

public void setTitle(String title) {
this.title = title;
}

public Category withTitle(String title) {
this.title = title;
return this;
}

public String getCreated_at() {
return created_at;
}

public void setCreated_at(String created_at) {
this.created_at = created_at;
}

public Category withCreated_at(String created_at) {
this.created_at = created_at;
return this;
}

public String getUpdated_at() {
return updated_at;
}

public void setUpdated_at(String updated_at) {
this.updated_at = updated_at;
}

public Category withUpdated_at(String updated_at) {
this.updated_at = updated_at;
return this;
}

public Integer getClues_count() {
return clues_count;
}

public void setClues_count(Integer clues_count) {
this.clues_count = clues_count;
}

public Category withClues_count(Integer clues_count) {
this.clues_count = clues_count;
return this;
}

@Override
public String toString() {
StringBuilder sb = new StringBuilder();
sb.append(Category.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
sb.append("id");
sb.append('=');
sb.append(((this.id == null)?"<null>":this.id));
sb.append(',');
sb.append("title");
sb.append('=');
sb.append(((this.title == null)?"<null>":this.title));
sb.append(',');
sb.append("created_at");
sb.append('=');
sb.append(((this.created_at == null)?"<null>":this.created_at));
sb.append(',');
sb.append("updated_at");
sb.append('=');
sb.append(((this.updated_at == null)?"<null>":this.updated_at));
sb.append(',');
sb.append("clues_count");
sb.append('=');
sb.append(((this.clues_count == null)?"<null>":this.clues_count));
sb.append(',');
if (sb.charAt((sb.length()- 1)) == ',') {
sb.setCharAt((sb.length()- 1), ']');
} else {
sb.append(']');
}
return sb.toString();
}

}