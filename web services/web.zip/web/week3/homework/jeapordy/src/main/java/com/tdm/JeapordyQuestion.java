//-----------------------------------tdm.Category.java-----------------------------------

package com.tdm;

public class JeapordyQuestion {

private Integer id;
private String answer;
private String question;
private Integer value;
private String airdate;
private String created_at;
private String updated_at;
private Integer category_id;
private Integer game_id;
private Object invalid_count;
private Category category;

/**
* No args constructor for use in serialization
*
*/
public JeapordyQuestion() {
}

/**
*
* @param answer
* @param question
* @param updated_at
* @param category_id
* @param airdate
* @param created_at
* @param invalid_count
* @param id
* @param category
* @param value
* @param game_id
*/
public JeapordyQuestion(Integer id, String answer, String question, Integer value, String airdate, String created_at, String updated_at, Integer category_id, Integer game_id, Object invalid_count, Category category) {
super();
this.id = id;
this.answer = answer;
this.question = question;
this.value = value;
this.airdate = airdate;
this.created_at = created_at;
this.updated_at = updated_at;
this.category_id = category_id;
this.game_id = game_id;
this.invalid_count = invalid_count;
this.category = category;
}

public Integer getId() {
return id;
}

public void setId(Integer id) {
this.id = id;
}

public JeapordyQuestion withId(Integer id) {
this.id = id;
return this;
}

public String getAnswer() {
return answer;
}

public void setAnswer(String answer) {
this.answer = answer;
}

public JeapordyQuestion withAnswer(String answer) {
this.answer = answer;
return this;
}

public String getQuestion() {
return question;
}

public void setQuestion(String question) {
this.question = question;
}

public JeapordyQuestion withQuestion(String question) {
this.question = question;
return this;
}

public Integer getValue() {
return value;
}

public void setValue(Integer value) {
this.value = value;
}

public JeapordyQuestion withValue(Integer value) {
this.value = value;
return this;
}

public String getAirdate() {
return airdate;
}

public void setAirdate(String airdate) {
this.airdate = airdate;
}

public JeapordyQuestion withAirdate(String airdate) {
this.airdate = airdate;
return this;
}

public String getCreated_at() {
return created_at;
}

public void setCreated_at(String created_at) {
this.created_at = created_at;
}

public JeapordyQuestion withCreated_at(String created_at) {
this.created_at = created_at;
return this;
}

public String getUpdated_at() {
return updated_at;
}

public void setUpdated_at(String updated_at) {
this.updated_at = updated_at;
}

public JeapordyQuestion withUpdated_at(String updated_at) {
this.updated_at = updated_at;
return this;
}

public Integer getCategory_id() {
return category_id;
}

public void setCategory_id(Integer category_id) {
this.category_id = category_id;
}

public JeapordyQuestion withCategory_id(Integer category_id) {
this.category_id = category_id;
return this;
}

public Integer getGame_id() {
return game_id;
}

public void setGame_id(Integer game_id) {
this.game_id = game_id;
}

public JeapordyQuestion withGame_id(Integer game_id) {
this.game_id = game_id;
return this;
}

public Object getInvalid_count() {
return invalid_count;
}

public void setInvalid_count(Object invalid_count) {
this.invalid_count = invalid_count;
}

public JeapordyQuestion withInvalid_count(Object invalid_count) {
this.invalid_count = invalid_count;
return this;
}

public Category getCategory() {
return category;
}

public void setCategory(Category category) {
this.category = category;
}

public JeapordyQuestion withCategory(Category category) {
this.category = category;
return this;
}

@Override
public String toString() {
StringBuilder sb = new StringBuilder();
sb.append(JeapordyQuestion.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
sb.append("id");
sb.append('=');
sb.append(((this.id == null)?"<null>":this.id));
sb.append(',');
sb.append("answer");
sb.append('=');
sb.append(((this.answer == null)?"<null>":this.answer));
sb.append(',');
sb.append("question");
sb.append('=');
sb.append(((this.question == null)?"<null>":this.question));
sb.append(',');
sb.append("value");
sb.append('=');
sb.append(((this.value == null)?"<null>":this.value));
sb.append(',');
sb.append("airdate");
sb.append('=');
sb.append(((this.airdate == null)?"<null>":this.airdate));
sb.append(',');
sb.append("created_at");
sb.append('=');
sb.append(((this.created_at == null)?"<null>":this.created_at));
sb.append(',');
sb.append("updated_at");
sb.append('=');
sb.append(((this.updated_at == null)?"<null>":this.updated_at));
sb.append(',');
sb.append("category_id");
sb.append('=');
sb.append(((this.category_id == null)?"<null>":this.category_id));
sb.append(',');
sb.append("game_id");
sb.append('=');
sb.append(((this.game_id == null)?"<null>":this.game_id));
sb.append(',');
sb.append("invalid_count");
sb.append('=');
sb.append(((this.invalid_count == null)?"<null>":this.invalid_count));
sb.append(',');
sb.append("category");
sb.append('=');
sb.append(((this.category == null)?"<null>":this.category));
sb.append(',');
if (sb.charAt((sb.length()- 1)) == ',') {
sb.setCharAt((sb.length()- 1), ']');
} else {
sb.append(']');
}
return sb.toString();
}

}