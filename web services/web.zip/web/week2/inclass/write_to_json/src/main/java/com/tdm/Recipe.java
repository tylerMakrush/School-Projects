package com.tdm;
import java.util.Map;
import java.util.List;


public class Recipe {
    private String RecipeName;
    private int Calories;
    private List<String> Ingredieants;
    private Map<String , String> Steps;
    private Boolean AllergyWarning;

    //setters and getters
    public String getRecipeName() {
        return RecipeName;
    }
    public void setRecipeName(String recipeName) {
        RecipeName = recipeName;
    }
    public int getCalories() {
        return Calories;
    }
    public void setCalories(int calories) {
        Calories = calories;
    }
    public List<String> getIngredieants() {
        return Ingredieants;
    }
    public void setIngredieants(List<String> ingredieants) {
        Ingredieants = ingredieants;
    }
    public Map<String, String> getSteps() {
        return Steps;
    }
    public void setSteps(Map<String, String> steps) {
        Steps = steps;
    }
    public Boolean getAllergyWarning() {
        return AllergyWarning;
    }
    public void setAllergyWarning(Boolean allergyWarning) {
        AllergyWarning = allergyWarning;
    }
    public Recipe(String recipeName, int calories, List<String> ingredieants, Map<String, String> steps,
            Boolean allergyWarning) {
        RecipeName = recipeName;
        Calories = calories;
        Ingredieants = ingredieants;
        Steps = steps;
        AllergyWarning = allergyWarning;
    }
    
    public Recipe() {
    }
    @Override
    public String toString() {
        return "Recipe [RecipeName=" + RecipeName + ", Calories=" + Calories + ", Ingredieants=" + Ingredieants
                + ", Steps=" + Steps + ", AllergyWarning=" + AllergyWarning + "]";
    }

    
    
}
