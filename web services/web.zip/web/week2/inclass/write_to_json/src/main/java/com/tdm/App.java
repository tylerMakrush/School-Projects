package com.tdm;

/**
 * Hello world!
 *
 */
import java.util.Arrays;
import java.util.*;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
public class App 
{
    public static void main( String[] args )
    {
       ObjectMapper mapper = new ObjectMapper();
       

       Recipe pbj = new Recipe();
       pbj.setRecipeName("[penut buder and jelly]");
       pbj.setCalories(180);
       pbj.setAllergyWarning(true);
       pbj.setIngredieants(Arrays.asList("2 pices of bread " , "penutbuder","jelly"));
      
       Map<String,String> theSteps = new HashMap(){
        {
        put("step1" , "put bread on plate");
        put("step2" , "Spread jelly on the bread");
        put("step3" , "put the bpices pf nread together");
        }
       };
       pbj.setSteps(theSteps);

       List<Recipe> recipeList = new ArrayList<Recipe>();
       recipeList.add(pbj);
       recipeList.add(pbj);
       recipeList.add(pbj);
       
       
       try{
        //String JSON = mapper.writeValueAsString(pbj);
        // String JSON = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(pbj);
        // System.out.println(JSON);
        String JSON = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(recipeList);
        System.out.println(JSON);
       }
       catch(JsonProcessingException jpe){
        System.out.println("json failed" + jpe.toString());
       }
    }
}
