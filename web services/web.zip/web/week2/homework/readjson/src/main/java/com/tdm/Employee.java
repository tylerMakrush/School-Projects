package com.tdm;
//package com.tylerreadjason;

import java.util.List;
//import javax.annotation.Generated;

//@Generated("jsonschema2pojo")
public class Employee {

private Integer id;
private String first_name;
private String last_name;
private String email;
private List<String> skill;
private Integer salary;

/**
* No args constructor for use in serialization
*
*/
public Employee() {
}

/**
*
* @param skill
* @param last_name
* @param id
* @param salary
* @param first_name
* @param email
*/
public Employee(Integer id, String first_name, String last_name, String email, List<String> skill, Integer salary) {
super();
this.id = id;
this.first_name = first_name;
this.last_name = last_name;
this.email = email;
this.skill = skill;
this.salary = salary;
}

public Integer getId() {
return id;
}

public void setId(Integer id) {
this.id = id;
}

public Employee withId(Integer id) {
this.id = id;
return this;
}

public String getFirst_name() {
return first_name;
}

public void setFirst_name(String first_name) {
this.first_name = first_name;
}

public Employee withFirst_name(String first_name) {
this.first_name = first_name;
return this;
}

public String getLast_name() {
return last_name;
}

public void setLast_name(String last_name) {
this.last_name = last_name;
}

public Employee withLast_name(String last_name) {
this.last_name = last_name;
return this;
}

public String getEmail() {
return email;
}

public void setEmail(String email) {
this.email = email;
}

public Employee withEmail(String email) {
this.email = email;
return this;
}

public List<String> getSkill() {
return skill;
}

public void setSkill(List<String> skill) {
this.skill = skill;
}

public Employee withSkill(List<String> skill) {
this.skill = skill;
return this;
}

public Integer getSalary() {
return salary;
}

public void setSalary(Integer salary) {
this.salary = salary;
}

public Employee withSalary(Integer salary) {
this.salary = salary;
return this;
}

@Override
public String toString() {
StringBuilder sb = new StringBuilder();
sb.append(Employee.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
sb.append("id");
sb.append('=');
sb.append(((this.id == null)?"<null>":this.id));
sb.append(',');
sb.append("first_name");
sb.append('=');
sb.append(((this.first_name == null)?"<null>":this.first_name));
sb.append(',');
sb.append("last_name");
sb.append('=');
sb.append(((this.last_name == null)?"<null>":this.last_name));
sb.append(',');
sb.append("email");
sb.append('=');
sb.append(((this.email == null)?"<null>":this.email));
sb.append(',');
sb.append("skill");
sb.append('=');
sb.append(((this.skill == null)?"<null>":this.skill));
sb.append(',');
sb.append("salary");
sb.append('=');
sb.append(((this.salary == null)?"<null>":this.salary));
sb.append(',');
if (sb.charAt((sb.length()- 1)) == ',') {
sb.setCharAt((sb.length()- 1), ']');
} else {
sb.append(']');
}
return sb.toString();
}

}