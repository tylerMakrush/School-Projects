package com.tdm;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import com.fasterxml.jackson.core.type.*;
import com.fasterxml.jackson.core.*;
import com.fasterxml.jackson.databind.*;
/**
 * Hello world!
 *
 */
public class App 
{
    private static List<Employee> employeeList = new ArrayList<Employee>();
    static int count = 0;

    public static String readAllLines(String path){
         String content = "";
        try {
            Files.readAllBytes(Paths.get(path));
            content = new String(Files.readAllBytes(Paths.get(path)));
        } catch (IOException iex) {
            System.out.println(iex.getMessage().toString());
            return "laaaaaaaaame";
        }
        return content;
    }
    public static int FindruExtentions(){
        int count =0;
        for(Employee anEmployee : employeeList){
            if(anEmployee.getEmail().contains("ru")){
                count++;
            }
        }
        return count;
    }
    public static double CalcAvSalary(){
        double avg = 0;
        double sum = 0;
        for(Employee anEmployee : employeeList){
            sum += anEmployee.getSalary();
        }
        avg =  sum / count;
        return avg;
    }
    public static void main( String[] args )
    {
        Employee anEmployee;
        ObjectMapper mapper = new ObjectMapper();
        double av = 0;
        int countru = 0;
        
        String json = readAllLines("C:\\web\\week2\\homework\\readjson\\employees.json");
        try{
            employeeList = mapper.readValue(json,new TypeReference<List<Employee>>() {   
            });
            count = employeeList.size();
            System.out.println("lines " + count);
        }
        catch(Exception ex){
            System.out.println(ex.getMessage().toString());
            return;
        }
        av = CalcAvSalary();
        countru = FindruExtentions();
        System.out.println("the avrage of the salaries is $" + av);
        System.out.println("there are " + countru + " with the ru extention on there email :)");
    }
}
