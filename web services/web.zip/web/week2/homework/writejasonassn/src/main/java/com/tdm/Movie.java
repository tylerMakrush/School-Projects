package com.tdm;
import java.util.*;
//import java.util.Arrays;
import java.util.Map;
import java.util.List;

public class Movie {
    private String MovieName;
    private int YearReleased;
    private List<String> Director;
    private String MPAARating;
    private Map<String,String> Actor_Role;
    private int MovieSequenceNumber;
    private double AmountGrossed;
    public String getMovieName() {
        return MovieName;
    }
    public void setMovieName(String movieName) {
        MovieName = movieName;
    }
    public int getYearReleased() {
        return YearReleased;
    }
    public void setYearReleased(int yearReleased) {
        YearReleased = yearReleased;
    }
    public List<String> getDirector() {
        return Director;
    }
    public void setDirector(List<String> director) {
        Director = director;
    }
    public String getMPAARating() {
        return MPAARating;
    }
    public void setMPAARating(String mPAARating) {
        MPAARating = mPAARating;
    }
    public Map<String, String> getActor_Role() {
        return Actor_Role;
    }
    public void setActor_Role(Map<String, String> actor_Role) {
        Actor_Role = actor_Role;
    }
    public int getMovieSequenceNumber() {
        return MovieSequenceNumber;
    }
    public void setMovieSequenceNumber(int movieSequenceNumber) {
        MovieSequenceNumber = movieSequenceNumber;
    }
    public double getAmountGrossed() {
        return AmountGrossed;
    }
    public void setAmountGrossed(double amountGrossed) {
        AmountGrossed = amountGrossed;
    }
    public Movie(String movieName, int yearReleased, List<String> director, String mPAARating,
            Map<String, String> actor_Role, int movieSequenceNumber, double amountGrossed) {
        MovieName = movieName;
        YearReleased = yearReleased;
        Director = director;
        MPAARating = mPAARating;
        Actor_Role = actor_Role;
        MovieSequenceNumber = movieSequenceNumber;
        AmountGrossed = amountGrossed;
    }
    public Movie() {
    }
    @Override
    public String toString() {
        return "Movie [MovieName=" + MovieName + ", YearReleased=" + YearReleased + ", Director=" + Director
                + ", MPAARating=" + MPAARating + ", Actor_Role=" + Actor_Role + ", MovieSequenceNumber="
                + MovieSequenceNumber + ", AmountGrossed=" + AmountGrossed + "]";
    }
    
}
