package com.tdm;
import java.util.*;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        ObjectMapper mapper = new ObjectMapper();

        Movie savingRyan = new Movie();
        savingRyan.setMovieName("Saving Privet Ryan");
        savingRyan.setYearReleased(1998);
        savingRyan.setDirector(Arrays.asList(" Steven Spielberg","again Steven Spielberg"));

        savingRyan.setMPAARating("R");
        savingRyan.setActor_Role(null);
        
        savingRyan.setMovieSequenceNumber(0);
        savingRyan.setAmountGrossed(482000000);
        
        Map<String,String> Actors = new HashMap(){
            {
                put("Miller", "Tom Hanks");
                put("Ryan", "Matt Damon");
                put("Ryan", "Matt Damon");
                put("Mike", "Tom Sizemore");
                put("Caparzo", "Vin Diesl");
            }
        };
        savingRyan.setActor_Role(Actors);


        try{
            String JSON = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(savingRyan);
            System.out.println(JSON);
        }
        catch(JsonProcessingException jpe){
            System.out.println("json fail >:(");
        }
        
    }
}
