package com.tdm.restservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.apache.http.HttpEntity;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

@SpringBootApplication
public class RestserviceApplication {
	final static CloseableHttpClient httpClient = HttpClients.createDefault();

	public static void getCheck(int id) throws ClientProtocolException, IOException{
		HttpGet request = new HttpGet("http://localhost:8080/courses");
		CloseableHttpResponse response = httpClient.execute(request);
        HttpEntity entity = response.getEntity();
        
        ObjectMapper mapper = new ObjectMapper();
        List<Course> courses = new ArrayList<Course>();
        courses = mapper.readValue(EntityUtils.toString(entity), new TypeReference<List<Course>>() {});

        for(Course room : courses){
            System.out.println(room.toString());
        }
	}
	public static void postCheck(int id, String courseName,int credits,String Instructor) throws Exception{
        HttpPost request = new HttpPost("http://localhost:8080/rooms");
        Course course = new Course();

        ObjectMapper mapper = new ObjectMapper();
        StringEntity json = new StringEntity(mapper.writeValueAsString(course), ContentType.APPLICATION_JSON);
        request.setEntity(json);

        CloseableHttpResponse response = httpClient.execute(request);
        if(response.getStatusLine().getStatusCode() !=200){
            System.out.println(course.toString());
        }
    }
	public static void putCheck() throws Exception{
		HttpPost request = new HttpPost("http://localhost:8080/rooms");
        Course course = new Course();

		ObjectMapper mapper = new ObjectMapper();
        StringEntity json = new StringEntity(mapper.writeValueAsString(course), ContentType.APPLICATION_JSON);
        request.setEntity(json);

		CloseableHttpResponse response = httpClient.execute(request);
        if(response.getStatusLine().getStatusCode() !=200){
            System.out.println(course.toString());
        }
	}
	public static void deleteCheck(int id) throws Exception{
		HttpPost request = new HttpPost("http://localhost:8080/rooms");
        Course course = new Course();

		ObjectMapper mapper = new ObjectMapper();
        StringEntity json = new StringEntity(mapper.writeValueAsString(course), ContentType.APPLICATION_JSON);
        request.setEntity(json);

		CloseableHttpResponse response = httpClient.execute(request);
        if(response.getStatusLine().getStatusCode() !=200){
            System.out.println(course.toString());
        }
	}
	public static void UserIn(){
		Scanner KeyBoard = new Scanner(System.in);
		int x = 0;
		int id = 0;
		String CourseName;
		int Credits;
		String Instructor;
		while(x != -1){
			System.out.println("if you would like to use the get feater press 1");
			System.out.println("if you would like to use the post feater press 2");
			System.out.println("if you would like to use the put feater press 3");
			System.out.println("if you would like to use the delete feater press 4");
			x = KeyBoard.nextInt();
			if(x == 1){
				System.out.println("plese type the class id of the class you want to see");
			id = KeyBoard.nextInt();
				getCheck(id);
			}
			if(x == 2){
			System.out.println("please enter class id you would like to make changes to");
			id = KeyBoard.nextInt();
			System.out.println("please enter class id you would like to make changes to");
			CourseName = KeyBoard.nextLine();
			System.out.println("please enter class credits");
			Credits = KeyBoard.nextInt();
			System.out.println("please enter class instructor");
			Instructor = KeyBoard.nextLine();
				postCheck(id,CourseName,Credits,Instructor);
			}
			if(x == 3){
			System.out.println("please enter a class id");
			id = KeyBoard.nextInt();
			System.out.println("please enter course name");
			CourseName = KeyBoard.nextLine();
			System.out.println("please enter class credits");
			Credits = KeyBoard.nextInt();
			System.out.println("please enter class instructor");
			Instructor = KeyBoard.nextLine();

				putCheck(id,CourseName,Credits,Instructor);
			}
			if(x == 4){
				System.out.println("please enter the id of the class you want to delete");
			id = KeyBoard.nextInt();
				deleteCheck(id);
			}
		}
	}

	public static void main(String[] args) {
		SpringApplication.run(RestserviceApplication.class, args);
		UserIn();

	}//closes main

}//closes class
