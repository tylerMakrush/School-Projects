package com.tdm.finalwebservice.CourseInfo;

public class Course {
    int ID;
    String CourseName;
    int Credits;
    String Instructor;
    public int getID() {
        return ID;
    }
    public void setID(int iD) {
        ID = iD;
    }
    public String getCourseName() {
        return CourseName;
    }
    public void setCourseName(String courseName) {
        CourseName = courseName;
    }
    public int getCredits() {
        return Credits;
    }
    public void setCredits(int credits) {
        Credits = credits;
    }
    public String getInstructor() {
        return Instructor;
    }
    public void setInstructor(String instructor) {
        Instructor = instructor;
    }
    public Course() {
    }
    public Course(int iD, String courseName, int credits, String instructor) {
        ID = iD;
        CourseName = courseName;
        Credits = credits;
        Instructor = instructor;
    }
    
}
