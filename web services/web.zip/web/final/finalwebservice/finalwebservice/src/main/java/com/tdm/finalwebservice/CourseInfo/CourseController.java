package com.tdm.finalwebservice.CourseInfo;
import java.nio.charset.Charset;
import java.util.*;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.apache.tomcat.util.codec.binary.Base64;
import java.io.File;
import java.io.FileNotFoundException;

@RestController
public class CourseController {
    static Map<Integer,Course> courses = new HashMap<Integer,Course>();

    public CourseController(){
        courses.put(1,new Course(1," ",3," "));
        File file = new File("final course data.csv");
        try{
            Scanner sc = new Scanner(file);
            while (sc.hasNextLine()) {
                //courses.put(x(sc));
                sc.nextLine();
            }
            sc.close();
        }
        catch(FileNotFoundException e){
            e.printStackTrace();
        }
    }
    @RequestMapping(value = "/courses", method = RequestMethod.GET)//handles get requests
    public ResponseEntity<List<Course>> getCourses(@RequestParam(value = "id" ,defaultValue = "0")int id ){
        List<Course> response = new ArrayList<>();
        switch (id) {
            case 0:
                response = new ArrayList<Course>(courses.values());                
                break;
        
            default:
                Course found = courses.get(id);
                if(found == null){
                    response.add(new Course(id,"course is empty ",3," " ));
                    return new ResponseEntity<List<Course>>(response,HttpStatus.NOT_FOUND);
                }
                else{
                    response.add(found);
                }
                break;
        }
        return new ResponseEntity<List<Course>>(response,HttpStatus.OK);
    }
    @RequestMapping(value = "/courses", method = RequestMethod.POST)//handles post
    public ResponseEntity<Course> postCourses(@RequestBody String newCourseID){
        ObjectMapper mapper = new ObjectMapper();
        Course response = new Course(-1,"error course not added",3,"");

        if(authenticate("") == true){
        try{//trys to enter the user input in to the class

            response = mapper.readValue(newCourseID, Course.class);
            if(courses.get(response.getID()) == null){//checks if the id is empty
                courses.put(response.getID(), response);
            }
            //if(courses.get(response.getCredits()) < 3){//checks if the cedits are less the 3
            //    courses.put(response.getID(), response);
            //}
            if(courses.isEmpty()){//checksif any of the fields are empty
                courses.put(response.getID(), response);
            }
        }
        catch(JsonProcessingException jme){//catches errors in the jason
            response.setCourseName(jme.getMessage().toString());
            return new ResponseEntity<Course>(response,HttpStatus.NOT_ACCEPTABLE);
        }
        return new ResponseEntity<Course>(response,HttpStatus.OK);//returns an ok status as well as the response transfered in jason format :)
    }
        response.setCourseName("not authorized");
        return new ResponseEntity<Course>(response,HttpStatus.NOT_ACCEPTABLE);//returns an ok status as well as the response transfered in jason format :)
    }
    @RequestMapping(value = "/courses", method = RequestMethod.PUT)//handles post
    public ResponseEntity<Course> putCourse(@RequestParam (value = "id")int id,
    @RequestParam(value = "added")String added){
        Course response = new Course(0,"",3,"");

        if(authenticate("") == true){
        if(courses.get(id) == null){
            response.setID(id);
            response.setCourseName("course needs to exist to add to it");
            return new ResponseEntity<Course>(response,HttpStatus.NOT_FOUND);
        }
        if(courses.get(id).getInstructor() == null){
            response.setID(id);
            response.setCourseName("course needs to have an instructor to add to");
            return new ResponseEntity<Course>(response,HttpStatus.NOT_FOUND);
        }

     return new ResponseEntity<Course>(response,HttpStatus.OK); 
    }
    response.setCourseName("not authorized");
    return new ResponseEntity<Course>(response,HttpStatus.NOT_ACCEPTABLE);
    }
    @RequestMapping(value = "/courses", method = RequestMethod.DELETE)
    public ResponseEntity<Course> deleteCourse(@RequestParam(value = "id")int id ){
        Course response = new Course();
        if(courses.get(id) == null){
            response.setCourseName("can not remove course if course does not exist");
            response.setID(id);
            return new ResponseEntity<Course>(response,HttpStatus.OK);
        }
        response.setCourseName("deleted");
        response.setID(id);
        courses.remove(id);
        return new ResponseEntity<Course>(response,HttpStatus.OK);
    }
    public boolean authenticate(String auth){//function that takes in the username and password and checks if its valid
        String userPass = auth.substring(6);	//why 6? - strip BASIC out
		byte[] decryptArray = Base64.decodeBase64(userPass);
		String decryptString = new String(decryptArray);
		int colon = decryptString.indexOf(":");	//find location of colon
		String userName = decryptString.substring(0, colon);
		String password = decryptString.substring(colon+1);
        boolean valid = false ;
        if(userName.equalsIgnoreCase("username")&&password.equals("password")){//chekcs if the user is allowed permision
            valid = true;
            return valid;
        }

        return valid;
    }
    public static String buildAuth(String username, String password){
        String temp = username + ":" + password;
        byte[] encoded = Base64.encodeBase64(temp.getBytes(Charset.forName("US-ASCII")), false);
        String authHeader = "Basic " + new String(encoded);
        return authHeader;
    }
}//closes course controller class
