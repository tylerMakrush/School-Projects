package com.tdm.finalwebservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinalwebserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
