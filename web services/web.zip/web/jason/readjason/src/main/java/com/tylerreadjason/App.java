package com.tylerreadjason;

import java.util.*;
import com.fasterxml.jackson.core.type.*;
import com.fasterxml.jackson.core.*;
import com.fasterxml.jackson.databind.*;

//import main.company;
import java.io.IOException;
import java.io.*;
import java.nio.file.*;

/**
 * Hello world!
 *
 */
public class App {
    private static List<Company> companyList = new ArrayList<Company>();
    static int counter = 0;

    // read all tje inthefile
    public static String readAllLines(String path) {
        String content = "";
        try {
            Files.readAllBytes(Paths.get(path));
            content = new String(Files.readAllBytes(Paths.get(path)));
        } catch (IOException iex) {
            System.out.println(iex.getMessage().toString());
            return "laaaaaaaaame";
        }
        return content;
    }

    public static void findNACompanies() {
        int naCount = 0;
        for (Company aCompany : companyList) {
            if (aCompany.getIndustry().equals("n/a")) {
                naCount++;
                System.out.println(aCompany.getCompany());
            }
        }
        System.out.println(naCount + " compinies with n/a");
    }

    public static void main(String[] args) {
        // System.out.println("Hello World!");
        Company aCompany;
        ObjectMapper mapper = new ObjectMapper();
        String json;
        json = readAllLines("C:\\web\\jason\\companies.json");
        try {
            companyList = mapper.readValue(json, new TypeReference<List<Company>>() {
            });// makes the list
            counter = companyList.size();
            System.out.println("lines " + counter);
            // System.out.println(companyList.get(5).toString());
            findNACompanies();
        } catch (Exception ex) {
            System.out.println(ex.getMessage().toString());
            return;
        }

    }
}
