package com.leecottrell.hotel.Rooms;

import java.util.*;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.fasterxml.jackson.core.JsonProcessingException;
//import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
public class RoomsController {
    static Map<Integer, Rooms> reservations = new HashMap<Integer, Rooms>();
    public RoomsController(){
        //setup you need for the controller
        reservations.put(515, new Rooms(515, "Cottrell"));
        reservations.put(603, new Rooms(603, "Schurter"));
        reservations.put(402, new Rooms(402, "Eltringham"));
    }

    //motify to acept an int peramater or no perameter
    @RequestMapping(value="/rooms", method=RequestMethod.GET)
    public ResponseEntity<List<Rooms>>getReservations(@RequestParam(value = "roomNum" , defaultValue = "0") int roomNum){
        //Collection<Rooms> results = reservations.values();
        //List<Rooms> response = new ArrayList<Rooms>(results);
        
        List<Rooms> response = new ArrayList<Rooms>();
        if(roomNum < 0 || roomNum > 616){
           response.add(new Rooms(roomNum,"Room number betweebn 1 and 616"));
           return new ResponseEntity<List<Rooms>>(response, HttpStatus.NOT_ACCEPTABLE);
        }
        switch (roomNum) {
            case 0:
                response = new ArrayList<Rooms>(reservations.values());
                break;
        
            default:
            Rooms found = reservations.get(roomNum);
            if(found == null){
                response.add(new Rooms(roomNum,"Room is Empty , ready to reserve !!!!"));
                 return new ResponseEntity<List<Rooms>>(response, HttpStatus.NOT_FOUND);
            }
            else{
               response.add(found); 
            }
            //pass int room number
                break;
        }
        
        return new ResponseEntity<List<Rooms>>(response, HttpStatus.OK);
    }

    //post will add a value to the map 
    //post will accept a jason document
    //post will check to see if room is legit and avalible
    @RequestMapping(value="/rooms", method=RequestMethod.PUT)
    public ResponseEntity<Rooms>putReservations(
    @RequestParam(value = "roomNum")int roomNum,
    @RequestParam(value = "addon") String addon ){
        Rooms response = new Rooms(0, "empty");
        if(reservations.get(roomNum) == null){
            response.setGuest("Room is not reserved , reserve before addons");
            response.setRoomNum(roomNum);
            return new ResponseEntity<Rooms>(response, HttpStatus.NOT_FOUND);
        }
        String origGuest = reservations.get(roomNum).getGuest();
        reservations.get(roomNum).setGuest(origGuest + " " + addon);

        response = reservations.get(roomNum);

        return new ResponseEntity<Rooms>(response, HttpStatus.OK);
    }

    @RequestMapping(value="/rooms", method=RequestMethod.POST)
    public ResponseEntity<Rooms>postReservations(@RequestBody String newRes){
        ObjectMapper mapper = new ObjectMapper();
        Rooms response = new Rooms(0, "Error in reservation , not added");

        try{

            response = mapper.readValue(newRes,Rooms.class);
            if(reservations.get(response.getRoomNum()) == null){
                reservations.put(response.getRoomNum(), response);
            }
            else{
                response.setGuest("Room is already reserved");
                 return new ResponseEntity<Rooms>(response,HttpStatus.NOT_ACCEPTABLE);
            }
            reservations.put(response.getRoomNum() , response);
        }catch(JsonProcessingException jme){
            response.setGuest(jme.getMessage().toString());
           return new ResponseEntity<Rooms>(response,HttpStatus.BAD_REQUEST);
        }

        return new ResponseEntity<Rooms>(response, HttpStatus.OK);
    }
    

    @RequestMapping(value="/rooms", method=RequestMethod.DELETE)
    public ResponseEntity<Rooms>deleteReservations(@RequestParam(value = "roomNum")int roomNum){
        Rooms response = new Rooms(0, "empty");
        if(reservations.get(roomNum) == null){
            response.setGuest("room is not reserved and cant be deleted");
            response.setRoomNum(roomNum);
            return new ResponseEntity<Rooms>(response, HttpStatus.NOT_IMPLEMENTED);
        }
        response.setGuest("deleted");
        response.setRoomNum(roomNum);
        reservations.remove(roomNum);
        return new ResponseEntity<Rooms>(response, HttpStatus.OK);
    }
}
