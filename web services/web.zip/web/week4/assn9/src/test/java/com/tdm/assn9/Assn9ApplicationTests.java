package com.tdm.assn9;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.doubleThat;

import java.net.MalformedURLException;
import java.net.URL;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.web.client.TestRestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tdm.assn9.Box.Box;
@SpringBootTest
class Assn9ApplicationTests {

	
	@Test
	public void testSizesmall(){
		Box aBox = new Box();
		aBox.boxName = "small";
		double expected = aBox.getHight();
		double actual=4;
		assertEquals(expected,actual);
	}
	@Test
	public void testSizeMedium(){
		Box aBox = new Box();
		aBox.boxName = "medium";
		double expected =aBox.getHight();
		double actual=6;
		assertEquals(expected,actual);
	}
	@Test
	public void testSizeLarge(){
		Box aBox = new Box();
		aBox.boxName = "large";
		double expected =aBox.getHight();
		double actual =8;
		assertEquals(expected,actual);
	}

	@Test
	public void testThickness(){
		Box aBox = new Box();
		aBox.boxName = "small";
		double actual = aBox.getThickness();
		double expected = .5;
		assertEquals(expected,actual);
	}

	
}
