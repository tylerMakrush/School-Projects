package com.tdm.assn9.Box;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class BoxController {
    @RequestMapping(value = "/Box",method = RequestMethod.GET)
    public ResponseEntity<Box> boxInfo(@RequestParam(defaultValue = "no name") String boxName){
        Box aBox = new Box();
        if(boxName.equalsIgnoreCase("small")){
            aBox.setBoxName(boxName);
            aBox.setHight(4);
            aBox.setLength(4);
            aBox.setWidth(4);
            aBox.setThickness(.5);
        }
        else if(boxName.equalsIgnoreCase("medium")){
            aBox.setBoxName(boxName);
            aBox.setHight(6);
            aBox.setLength(6);
            aBox.setWidth(6);
            aBox.setThickness(.5);
        }
        else if(boxName.equalsIgnoreCase("large")){
            aBox.setBoxName(boxName);
            aBox.setHight(8);
            aBox.setLength(8);
            aBox.setWidth(8);
            aBox.setThickness(.5);
        }
        else{
            aBox.setBoxName(boxName);
            aBox.setHight(0);
            aBox.setLength(0);
            aBox.setWidth(0);
            aBox.setThickness(.0);
        }

        return new ResponseEntity<Box>(aBox ,HttpStatus.OK);
    }
}
