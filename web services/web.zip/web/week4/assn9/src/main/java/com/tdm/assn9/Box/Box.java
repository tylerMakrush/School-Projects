package com.tdm.assn9.Box;

public class Box {
    public String boxName;
    public double Length;
    public double Width;
    public double Hight;
    public double Thickness;
   
    public String getBoxName() {
        return boxName;
    }
    public void setBoxName(String boxName) {
        this.boxName = boxName;
    }
    public double getLength() {
        return Length;
    }
    public void setLength(double length) {
        Length = length;
    }
    public double getWidth() {
        return Width;
    }
    public void setWidth(double width) {
        Width = width;
    }
    public double getHight() {
        return Hight;
    }
    public void setHight(double hight) {
        Hight = hight;
    }
    public double getThickness() {
        return Thickness;
    }
    public void setThickness(double thickness) {
        Thickness = thickness;
    }
    public Box(String boxName, double length, double width, double hight, double thickness) {
        this.boxName = boxName;
        Length = length;
        Width = width;
        Hight = hight;
        Thickness = thickness;
    }
    public Box() {
    }
    public double calcOutsideVolume(){
        return getHight() * getLength() * getWidth();
    }
    public double calcInsideVolume(){
        
        return (getLength() - getWidth()) * (getWidth() - getThickness()) * (getHight() - getThickness());
    }
    public double calcInsideDimensions(){
        return (getLength() - getThickness()) + (getLength() - getThickness() * 2) + (getHight() - getThickness() * 2);
    }
    public double calcSurfaceArea(){
        return (getLength() * getWidth()) +2 *(getLength() *getHight()) +2 * (getWidth()* getHight()) ;
    }
    public double calcWeight(){
        return (calcOutsideVolume() - calcInsideVolume() - getLength() * getWidth() * getHight() ) *.283;
    }
    public double calcCost(){
        return 1.58 * calcWeight();
    }
    @Override
    public String toString() {
        return "Box [boxName=" + boxName + ", Length=" + Length + ", Width=" + Width + ", Hight=" + Hight
                + ", Thickness=" + Thickness + "]"
                + " outside volume " + calcOutsideVolume() + " inside volume " + calcInsideVolume()
        + " inside dimensions " + calcInsideDimensions() + " surface area " + calcSurfaceArea()
        + " Weight " + calcWeight() + " cost$" + calcCost()        
        + "}" ;
    }
    
}
