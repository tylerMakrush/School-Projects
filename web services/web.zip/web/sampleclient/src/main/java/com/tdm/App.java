package com.tdm;

import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import java.util.Scanner;

import javax.swing.JOptionPane;

/**
 * Hello world!
 *
 */

public class App {
    final static CloseableHttpClient httoClient = HttpClients.createDefault();

    public static void main(String[] args) {
        Scanner userscan = new Scanner(System.in);
        System.out.println("please enter your postal code");

        String user = userscan.nextLine();
        try {
            HttpGet request = new HttpGet("https://api.zippopotam.us/us/" + user);
            CloseableHttpResponse response = httoClient.execute(request);
            HttpEntity entity = response.getEntity();
            JOptionPane.showMessageDialog(null, EntityUtils.toString(entity));
        } catch (Exception ex) {
            System.out.println("you got sum problemz fix em or no cool api stoof 4 u >:(");
            System.out.println("you probably entered an invalade postal code please restart and try agan");
            System.out.println(ex.toString());
            System.exit(1);
        }

    }
}
