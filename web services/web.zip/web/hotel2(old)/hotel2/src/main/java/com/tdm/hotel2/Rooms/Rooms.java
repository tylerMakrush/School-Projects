package com.tdm.hotel2.Rooms;

public class Rooms {
    int roomNum;
    String guest;
    public int getRoomNum() {
        return roomNum;
    }
    public void setRoomNum(int roomNum) {
        this.roomNum = roomNum;
    }
    public String getGuest() {
        return guest;
    }
    public void setGuest(String guest) {
        this.guest = guest;
    }
    public Rooms() {
    }
    public Rooms(int roomNum, String guest) {
        this.roomNum = roomNum;
        this.guest = guest;
    }
    
    
}
