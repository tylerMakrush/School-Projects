package com.tdm.hotel2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Hotel2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
