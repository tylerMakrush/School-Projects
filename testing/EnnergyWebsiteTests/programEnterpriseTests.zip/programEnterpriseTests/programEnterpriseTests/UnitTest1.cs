using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
namespace programEnterpriseTests
{
    public class UnitTest1
    {
        //page tests
        IWebDriver driver = new ChromeDriver("");// no current URL
        /// <summary>
        /// //these tests are all from home from a ogged in account
        [Fact]
        public void TestButtontoLogIN()//can copy past for each page type when have the code
        {
            driver = new ChromeDriver("");
            WebElement button = (WebElement)driver.FindElement(By.Id("button"));
            WebElement page = (WebElement)driver.FindElement(By.Id("title"));
            WebElement seconDPage = (WebElement)driver.FindElement(By.Id("title"));
            button.Click();

            Assert.NotEqual(page,seconDPage);// should not equal eachother becouse if button works it will take you to a diffent page


        }
        [Fact]
        public void TestButtonWind()
        {
            driver = new ChromeDriver("");
            WebElement button = (WebElement)driver.FindElement(By.Id("button"));
            WebElement page = (WebElement)driver.FindElement(By.Id("title"));
            WebElement seconDPage = (WebElement)driver.FindElement(By.Id("title"));
            button.Click();

            Assert.NotEqual(page, seconDPage);


        }
        [Fact]
        public void TestButtonNukelear()
        {
            driver = new ChromeDriver("");
            WebElement button = (WebElement)driver.FindElement(By.Id("button"));
            WebElement page = (WebElement)driver.FindElement(By.Id("title"));
            WebElement seconDPage = (WebElement)driver.FindElement(By.Id("title"));
            button.Click();

            Assert.NotEqual(page, seconDPage);

        }
        [Fact]
        public void TestButtonHydro()
        {
            driver = new ChromeDriver("");
            WebElement button = (WebElement)driver.FindElement(By.Id("button"));
            WebElement page = (WebElement)driver.FindElement(By.Id("title"));
            WebElement seconDPage = (WebElement)driver.FindElement(By.Id("title"));
            button.Click();

            Assert.NotEqual(page, seconDPage);


        }
        [Fact]
        public void TestButtonGreenEnergy()
        {
            driver = new ChromeDriver("");
            WebElement button = (WebElement)driver.FindElement(By.Id("button"));
            WebElement page = (WebElement)driver.FindElement(By.Id("title"));
            WebElement seconDPage = (WebElement)driver.FindElement(By.Id("title"));
            button.Click();

            Assert.NotEqual(page, seconDPage);


        }
        [Fact]
        public void TestButtonGeo()
        {
            driver = new ChromeDriver("");
            WebElement button = (WebElement)driver.FindElement(By.Id("button"));
            WebElement page = (WebElement)driver.FindElement(By.Id("title"));
            WebElement seconDPage = (WebElement)driver.FindElement(By.Id("title"));
            button.Click();

            Assert.NotEqual(page, seconDPage);


        }
        [Fact]
        public void TestButtonfusion()
        {
            driver = new ChromeDriver("");
            WebElement button = (WebElement)driver.FindElement(By.Id("button"));
            WebElement page = (WebElement)driver.FindElement(By.Id("title"));
            WebElement seconDPage = (WebElement)driver.FindElement(By.Id("title"));
            button.Click();

            Assert.NotEqual(page, seconDPage);
        }
        [Fact]
        public void TestButtonsourceOne()
        {
            driver = new ChromeDriver("");
            WebElement Link = (WebElement)driver.FindElement(By.Id("Link"));
            WebElement page = (WebElement)driver.FindElement(By.Id("title"));
            WebElement seconDPage = (WebElement)driver.FindElement(By.Id("title"));
            Link.Click();

            Assert.NotEqual(page, seconDPage);
        }
        /// </summary>

        [Fact]//tests the page pops up:)
        public void testhomePage()//tests home page luanch
        {
            driver = new ChromeDriver("");//the login web page
            WebElement title = (WebElement)driver.FindElement(By.Id("title"));

            Assert.NotEmpty((System.Collections.IEnumerable)title);
        }




        //tests the user login and signng up
        [Fact]
        public void testCanLogin()//tests if user can log in
        {
            driver = new ChromeDriver("");//the login web page
            WebElement userName = (WebElement)driver.FindElement(By.Id("username"));//finds user name and password boxes
            WebElement password = (WebElement)driver.FindElement(By.Id("password"));

            userName.SendKeys("password");
            password.SendKeys("users");

            driver.FindElement(By.XPath("")).Click();

            WebElement signin = (WebElement)driver.FindElement(By.Id("signin"));


            Assert.Empty((System.Collections.IEnumerable)signin);
        }
        [Fact]
        public void testCanLoginwrongPassword()
        {
            driver = new ChromeDriver("");//the login web page
            WebElement userName = (WebElement)driver.FindElement(By.Id("username"));//finds user name and password boxes
            WebElement password = (WebElement)driver.FindElement(By.Id("password"));

            userName.SendKeys("wrongPassword");
            password.SendKeys("users");

            driver.FindElement(By.XPath("")).Click();

            WebElement signin = (WebElement)driver.FindElement(By.Id("signin"));


            Assert.Empty((System.Collections.IEnumerable)signin);
        }
        [Fact]
        public void testSighUp()//tests if the user can sign up on site
        {
            driver = new ChromeDriver("");//the login web page
            WebElement userName = (WebElement)driver.FindElement(By.Id("username"));
            WebElement password = (WebElement)driver.FindElement(By.Id("password"));

            userName.SendKeys("password");
            password.SendKeys("users");

            //will need to make sure the 2 step authentication is done so the person can log in


            driver.FindElement(By.XPath("")).Click();
            WebElement createAcount = (WebElement)driver.FindElement(By.Id("createBtn"));



            Assert.Empty((System.Collections.IEnumerable)createAcount);


        }//this function will need the account to be removed from database when functonal
        //test database security and data
        [Fact]
        public void testSQInjectionUserName()//checks to see if the user can enter sql to mess with database from thereusername 
        {
            driver = new ChromeDriver("");//the login web page
            WebElement userName = (WebElement)driver.FindElement(By.Id("username"));
            WebElement password = (WebElement)driver.FindElement(By.Id("password"));

            userName.SendKeys("select * from {enter table here}");//change this to table name
            password.SendKeys("users");


            driver.FindElement(By.XPath("")).Click();
            WebElement createAcount = (WebElement)driver.FindElement(By.Id("createBtn"));



            Assert.Empty((System.Collections.IEnumerable)createAcount);
        }
        [Fact]
        public void testSQInjectionPassword()//checks to see if the user can enter sql to mess with database from thereusername 
        {
            driver = new ChromeDriver("");
            WebElement userName = (WebElement)driver.FindElement(By.Id("username"));
            WebElement password = (WebElement)driver.FindElement(By.Id("select * from {enter table here}"));//this will need to be changed to the databases table name

            userName.SendKeys("password");
            password.SendKeys("users");


            driver.FindElement(By.XPath("")).Click();
            WebElement createAcount = (WebElement)driver.FindElement(By.Id("createBtn"));



            Assert.Empty((System.Collections.IEnumerable)createAcount);
        }
        [Fact]
        public void testCantGetInWithOutauthentication()//tests the user must use 2 step authentication becore they can proceed
        {
            driver = new ChromeDriver("");//the login web page
            WebElement userName = (WebElement)driver.FindElement(By.Id("username"));
            WebElement password = (WebElement)driver.FindElement(By.Id("password"));

            userName.SendKeys("password");
            password.SendKeys("users");


            driver.FindElement(By.XPath("")).Click();
            WebElement createAcount = (WebElement)driver.FindElement(By.Id("createBtn"));



            Assert.Empty((System.Collections.IEnumerable)createAcount);

        }



        //logic tests 



        ////zips on hold :(
        //[Fact]
        //public void testRightZipAppersWhenEntered()//this tests that when the user inputs there zip the right data is pulled out of the data base
        //{
        //    driver = new ChromeDriver("");
        //    WebElement zipEnter = (WebElement)driver.FindElement(By.Id("ZipID"));
        //    zipEnter.SendKeys("10000");//find a better number in the futer when dev


        //}
        //[Fact]
        //public void testWrongZipDoesNotReturnAnyThing()//this tests that when the user inputs not a zip in our system it does not nuke
        //{
        //    driver = new ChromeDriver("");
        //    WebElement zipEnter = (WebElement)driver.FindElement(By.Id("ZipID"));
        //    zipEnter.SendKeys("10000");//enter in a zip that does not exist
        //}
        //[Fact]
        //public void testNegitiveZipCode()//this tests that when the user inputs not a zip in our system it does not nuke
        //{
        //    driver = new ChromeDriver("");
        //    WebElement zipEnter = (WebElement)driver.FindElement(By.Id("ZipID"));
        //    zipEnter.SendKeys("-10000");//enter in a zip that does not exist
        //}
        //[Fact]
        //public void testRightZipEnterLettersNotInts()//this tests that when the user inputs letters for the zip
        //{
        //    driver = new ChromeDriver("");
        //    WebElement zipEnter = (WebElement)driver.FindElement(By.Id("ZipID"));
        //    zipEnter.SendKeys("abcdefg");
        //}

        
    }
}